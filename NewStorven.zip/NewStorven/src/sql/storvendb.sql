-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2025 at 08:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `storvendb`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`user_id`, `fname`, `lname`, `username`, `password`, `role`) VALUES
(1, 'Mark Jeshmer', 'Jaromahum', 'Mrxtrm', 'Password123', 'Admin'),
(4, 'M', 'J', '1', '1', 'Admin'),
(5, '1', '1', '1', '2', 'User'),
(7, 'Mark', 'Storm', 'User', 'Pass', 'User'),
(8, 'Marki', 'Plier', 'XD', 'haha', 'User'),
(9, 'm', 'm', '2', '2', 'User'),
(10, 'Feny Ann', 'Cervantes', 'ceannix', '12345', 'User'),
(11, 'Lyn', 'Nyl', 'okay', '123456789', 'Admin'),
(12, 'jed', 'edo', 'joward', '123', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `product_id` int(100) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `category` varchar(250) NOT NULL,
  `stock_level` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 0,
  `price` decimal(10,2) UNSIGNED NOT NULL DEFAULT 0.00,
  `expiration_date` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`product_id`, `product_name`, `category`, `stock_level`, `reorder_level`, `price`, `expiration_date`) VALUES
(2, 'Lucky Me Pancit Canton(Chilimansi)', 'Canned & Instant Foods', 50, 5, 15.00, '02-05-2027'),
(4, 'Magic Sarap', 'Cooking Essentials', 64, 5, 5.00, '07-29-2028'),
(5, 'Pride Bar', 'Laundry & Cleaning Supplies', 30, 5, 24.00, 'N/A'),
(6, 'Lucky Me Noodles (Beef)', 'Canned & Instant Foods', 89, 5, 10.00, '11-21-2026'),
(7, 'Holiday Beef Loaf', 'Canned & Instant Foods', 48, 5, 26.00, '11-03-2027'),
(8, 'Cracklings', 'Snacks', 23, 5, 10.00, '02-07-2026'),
(9, 'Coca-Cola 190mL', 'Beverages', 24, 5, 15.00, '11-09-2025'),
(10, 'Coca-Cola 1L', 'Beverages', 99, 5, 45.00, '08-12-2025'),
(11, 'Chuckie', 'Beverages', 25, 5, 18.00, '04-29-2025'),
(12, 'Wings Solve Powder', 'Laundry & Cleaning Supplies', 100, 10, 8.00, 'N/A'),
(13, 'Surf Powder (Rose Fresh)', 'Laundry & Cleaning Supplies', 100, 10, 8.00, 'N/A'),
(14, 'Tang Orange', 'Powdered Drinks', 80, 10, 22.00, '12-08-2025'),
(15, 'Tawas', 'Personal Care', 15, 5, 11.00, 'N/A'),
(16, '1/4 Pad Paper (80 Leaves)', 'School & Office Supplies', 20, 10, 24.00, 'N/A'),
(17, '1/2 Pad Paper Lengthwise (80 Leaves)', 'School & Office Supplies', 20, 10, 21.00, 'N/A'),
(18, '1/2 Pad  Paper Crosswise (80 Leaves)', 'Snacks', 20, 10, 21.00, 'N/A'),
(19, '1/2 Pad Paper Lengthwise (50 Leaves)', 'School & Office Supplies', 20, 10, 19.00, 'N/A'),
(20, '1/2 Pad Paper Crosswise (50 Leaves)', 'School & Office Supplies', 20, 10, 19.00, 'N/A'),
(21, 'Tang Grapes', 'Powdered Drinks', 50, 10, 22.00, '12-07-2025'),
(22, 'Mega Sardines Spicy', 'Canned & Instant Foods', 20, 10, 26.00, '09-14-2025'),
(23, 'Mega Sardines', 'Canned & Instant Foods', 20, 10, 26.00, '09-26-2026'),
(24, 'Yellow Pad', 'School & Office Supplies', 20, 10, 36.00, 'N/A'),
(25, 'Cream Silk', 'Laundry & Cleaning Supplies', 90, 10, 8.00, 'N/A'),
(26, 'Sun Silk', 'Laundry & Cleaning Supplies', 90, 10, 10.00, 'N/A'),
(27, 'Safe Guard Pink', 'Laundry & Cleaning Supplies', 30, 10, 30.00, 'N/A'),
(28, 'Choco Knots', 'Snacks', 50, 10, 10.00, '07-14-2025'),
(29, 'Crispy Patata', 'Snacks', 40, 10, 10.00, '06-24-2025'),
(30, 'Chippy', 'Snacks', 40, 10, 10.00, '04-17-2026'),
(31, 'Mongol Pencil #2 Medium Yellow  12/Box', 'School & Office Supplies', 30, 10, 119.00, 'N/A'),
(32, 'Mongol Pencil #2 Medium (1pc)', 'School & Office Supplies', 40, 10, 12.00, 'N/A'),
(33, 'HBOffice ULTRA Eraser E-07', 'School & Office Supplies', 50, 10, 20.00, 'N/A'),
(34, 'Faber Castell 1423 Ballpoint Pen Black', 'School & Office Supplies', 50, 10, 16.00, 'N/A'),
(35, 'Rover Sprint Ballpoint Pen Stick 0.5mm', 'School & Office Supplies', 50, 10, 8.00, 'N/A'),
(36, '1kg Oil', 'Cooking Essentials', 20, 10, 90.00, 'N/A'),
(37, '1/2 Oil', 'Snacks', 20, 10, 45.00, 'N/A'),
(38, 'Salt', 'Cooking Essentials', 20, 10, 10.00, 'N/A'),
(39, 'Safe Guard Yellow', 'Laundry & Cleaning Supplies', 20, 10, 30.00, 'N/A'),
(40, 'Safe Guard Blue', 'Laundry & Cleaning Supplies', 10, 10, 30.00, 'N/A'),
(41, 'Nestea Iced Tea Lemon Blend 20g', 'Powdered Drinks', 30, 10, 22.00, '01-28-2026'),
(42, 'Nestea Iced Tea Apple 20g', 'Powdered Drinks', 20, 10, 22.00, '01-24-2026'),
(43, 'Onion Rings', 'Snacks', 20, 10, 10.00, '09-12-2025'),
(44, 'Bond Paper (1pc)', 'School & Office Supplies', 100, 10, 1.25, 'N/A'),
(45, 'Downey Black Perfume', 'Laundry & Cleaning Supplies', 20, 10, 12.00, 'N/A'),
(46, 'Downey Sunrise', 'Laundry & Cleaning Supplies', 30, 10, 12.00, 'N/A'),
(47, 'Clover Cheese Flavor', 'Snacks', 20, 10, 10.00, '09-29-2025');

-- --------------------------------------------------------

--
-- Table structure for table `salerecords`
--

CREATE TABLE `salerecords` (
  `sales_id` int(110) NOT NULL,
  `product_id` int(110) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `quantity_sold` int(250) NOT NULL,
  `sale_amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `salerecords`
--

INSERT INTO `salerecords` (`sales_id`, `product_id`, `product_name`, `quantity_sold`, `sale_amount`) VALUES
(3, 2, 'Lucky Me Pancit Canton(Chilimansi)', 3, 45),
(4, 2, 'Lucky Me Pancit Canton(Chilimansi)', 1, 15);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(100) NOT NULL,
  `product_id` int(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `unit_price` double NOT NULL,
  `subtotal` double NOT NULL,
  `sale_date` date NOT NULL DEFAULT current_timestamp(),
  `quantity_sold` int(100) NOT NULL,
  `total_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `salerecords`
--
ALTER TABLE `salerecords`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `salerecords`
--
ALTER TABLE `salerecords`
  MODIFY `sales_id` int(110) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
