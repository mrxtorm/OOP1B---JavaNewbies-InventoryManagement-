
package src;

import java.sql.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.XChartPanel;
import org.knowm.xchart.style.Styler;

public final class UserView extends javax.swing.JFrame {

    public UserView() {
        initComponents();
        
        setLocationRelativeTo(null);
        
        initChart();
        loadData();
        loadProductsIntoComboBox();
        
    }

//HOMEPAGE COMPONENTS    
    private void initChart() {
        // Get data from database
        Map<String, Integer> categoryCounts = getCategoryCounts();

        // Check if we have data to display
        if (categoryCounts.isEmpty()) {
            GraphPanel.removeAll();

            JLabel noDataLabel = new JLabel("No inventory data available to display chart", SwingConstants.CENTER);
            noDataLabel.setFont(new Font("Arial", Font.BOLD, 16));
            noDataLabel.setForeground(Color.GRAY);
            noDataLabel.setHorizontalTextPosition(SwingConstants.CENTER);
            noDataLabel.setVerticalTextPosition(SwingConstants.BOTTOM);

            GraphPanel.setLayout(new BorderLayout()); // ensure it fills the panel
            GraphPanel.add(noDataLabel, BorderLayout.CENTER);

            GraphPanel.revalidate();
            GraphPanel.repaint();
            return;
        }


        // Create Chart
        CategoryChart chart = new CategoryChartBuilder()
                .width(800)
                .height(400)
                .title("Inventory Overview")
                .xAxisTitle("Category")
                .yAxisTitle("Quantity")
                .build();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setLegendVisible(false);
        chart.getStyler().setAvailableSpaceFill(0.98);

        // Add Series
        chart.addSeries("Products in Stock", 
                new ArrayList<>(categoryCounts.keySet()), 
                new ArrayList<>(categoryCounts.values()));

        // Convert to Swing component
        JPanel chartPanel = new XChartPanel<>(chart);
        GraphPanel.removeAll();
        GraphPanel.add(chartPanel, BorderLayout.CENTER);
        GraphPanel.revalidate();
    }
       
    private Map<String, Integer> getCategoryCounts() {
        Map<String, Integer> counts = new HashMap<>();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT category, SUM(stock_level) as total FROM inventory GROUP BY category")) {

            while (rs.next()) {
                counts.put(rs.getString("category"), rs.getInt("total"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading category data: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        // Return empty map instead of null if no data
        return counts.isEmpty() ? Collections.emptyMap() : counts;
    }
//END HOMEPAGE COMPONENTS

//INVENTORY COMPONENTS    
    public void loadData() {
        // Load data into tableAllProducts
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM inventory")) {
            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱ " + rs.getString("price")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory for All Products: " + e.getMessage());
        }

        // Load data into tableProductExpiration
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM inventory")) {
            while (rs.next()) {
                model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date"),
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory for Product Expiration: " + e.getMessage());
        }
    }
//END INVENTORY COMPONENTS
    
//RECORD SALES COMPONENTS
    private boolean isLoadingProducts = true;

    private void loadProductsIntoComboBox() {
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", ""); // change username/password if needed
        String sql = "SELECT product_name FROM inventory";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        cmbSelectProduct.removeAllItems(); // Clear default items first
        while (rs.next()) {
            cmbSelectProduct.addItem(rs.getString("product_name"));
        }
        
        con.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error loading products: " + e.getMessage());
    }
}
    
    private void updateTotal() {
        DefaultTableModel model = (DefaultTableModel) tableRecordSales.getModel();
        double total = 0;
        for (int i = 0; i < model.getRowCount(); i++) {
            double subtotal = (double) model.getValueAt(i, 3);
            total += subtotal;
        }
        labelTotalPrice.setText(String.format("₱%.2f", total));
    }

    private double getProductPrice(String productName) {
        double price = -1;
        try {Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            String sql = "SELECT price FROM inventory WHERE product_name=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, productName);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                price = rs.getDouble("price");
            }
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return price;
    }

    private int getAvailableStock(String productName) {
        int stock = 0;
        try {Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            String sql = "SELECT stock_level FROM inventory WHERE product_name=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, productName);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                stock = rs.getInt("stock_level");
            }
            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stock;
    }
//END RECORD SALES COMPONENTS
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LeftPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnHome = new javax.swing.JToggleButton();
        btnInventory = new javax.swing.JToggleButton();
        btnRecordSales = new javax.swing.JToggleButton();
        btnAlerts = new javax.swing.JToggleButton();
        btnLogout = new javax.swing.JToggleButton();
        UserParent = new javax.swing.JPanel();
        HomePage = new javax.swing.JPanel();
        TopPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        GraphPanel = new javax.swing.JPanel();
        ViewInventoryPage = new javax.swing.JPanel();
        TopPanel = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        btnProductExpiration = new javax.swing.JToggleButton();
        txtSearchProduct = new javax.swing.JTextField();
        btnSearchProduct = new javax.swing.JButton();
        TableParent = new javax.swing.JPanel();
        scrollpAllProducts = new javax.swing.JScrollPane();
        tableAllProducts = new javax.swing.JTable();
        scrollpProductExpiration = new javax.swing.JScrollPane();
        tableProductExpiration = new javax.swing.JTable();
        RecordSalesPage = new javax.swing.JPanel();
        TopPanel2 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cmbSelectProduct = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        txtQuantity = new javax.swing.JTextField();
        btnAdd = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableRecordSales = new javax.swing.JTable();
        btnRemove = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        labelTotalPrice = new javax.swing.JLabel();
        btnClear = new javax.swing.JButton();
        btnRecord = new javax.swing.JButton();
        AlertsPage = new javax.swing.JPanel();
        TopPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LeftPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 120x120.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setPreferredSize(new java.awt.Dimension(0, 0));

        btnHome.setBackground(new java.awt.Color(255, 255, 255));
        btnHome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnHome.setForeground(new java.awt.Color(0, 0, 51));
        btnHome.setText("  Home");
        btnHome.setBorder(null);
        btnHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnHome.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        btnInventory.setBackground(new java.awt.Color(255, 255, 255));
        btnInventory.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnInventory.setForeground(new java.awt.Color(0, 0, 51));
        btnInventory.setText("  View Inventory");
        btnInventory.setBorder(null);
        btnInventory.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnInventory.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnInventory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventoryActionPerformed(evt);
            }
        });

        btnRecordSales.setBackground(new java.awt.Color(255, 255, 255));
        btnRecordSales.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnRecordSales.setForeground(new java.awt.Color(0, 0, 51));
        btnRecordSales.setText("  Record Sales");
        btnRecordSales.setBorder(null);
        btnRecordSales.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnRecordSales.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnRecordSales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordSalesActionPerformed(evt);
            }
        });

        btnAlerts.setBackground(new java.awt.Color(255, 255, 255));
        btnAlerts.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnAlerts.setForeground(new java.awt.Color(0, 0, 51));
        btnAlerts.setText("  Alerts");
        btnAlerts.setBorder(null);
        btnAlerts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnAlerts.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnAlerts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlertsActionPerformed(evt);
            }
        });

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(0, 0, 51));
        btnLogout.setText("  Logout");
        btnLogout.setBorder(null);
        btnLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLogout.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout LeftPanelLayout = new javax.swing.GroupLayout(LeftPanel);
        LeftPanel.setLayout(LeftPanelLayout);
        LeftPanelLayout.setHorizontalGroup(
            LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftPanelLayout.createSequentialGroup()
                .addGroup(LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnRecordSales, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnAlerts, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnInventory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnHome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        LeftPanelLayout.setVerticalGroup(
            LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInventory, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRecordSales, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAlerts, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        UserParent.setPreferredSize(new java.awt.Dimension(0, 0));
        UserParent.setLayout(new java.awt.CardLayout());

        HomePage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 51));
        jLabel10.setText("User Home Page");

        javax.swing.GroupLayout TopPanel1Layout = new javax.swing.GroupLayout(TopPanel1);
        TopPanel1.setLayout(TopPanel1Layout);
        TopPanel1Layout.setHorizontalGroup(
            TopPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(486, Short.MAX_VALUE))
        );
        TopPanel1Layout.setVerticalGroup(
            TopPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        GraphPanel.setLayout(new java.awt.CardLayout());

        javax.swing.GroupLayout HomePageLayout = new javax.swing.GroupLayout(HomePage);
        HomePage.setLayout(HomePageLayout);
        HomePageLayout.setHorizontalGroup(
            HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(HomePageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(GraphPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        HomePageLayout.setVerticalGroup(
            HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePageLayout.createSequentialGroup()
                .addComponent(TopPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(GraphPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        UserParent.add(HomePage, "card2");

        ViewInventoryPage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 51));
        jLabel9.setText("Inventory");

        javax.swing.GroupLayout TopPanelLayout = new javax.swing.GroupLayout(TopPanel);
        TopPanel.setLayout(TopPanelLayout);
        TopPanelLayout.setHorizontalGroup(
            TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TopPanelLayout.setVerticalGroup(
            TopPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cmbCategory.setBackground(new java.awt.Color(0, 51, 102));
        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Snacks", "Canned & Instant Foods", "Beverages", "Powdered Drinks", "Cooking Essentials", "Personal Care", "Laundry & Cleaning Supplies", "School & Office Supplies" }));
        cmbCategory.setToolTipText("Category");
        cmbCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategoryActionPerformed(evt);
            }
        });

        btnProductExpiration.setBackground(new java.awt.Color(0, 51, 102));
        btnProductExpiration.setForeground(new java.awt.Color(255, 255, 255));
        btnProductExpiration.setText("Product Expiration");
        btnProductExpiration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductExpirationActionPerformed(evt);
            }
        });

        txtSearchProduct.setBackground(new java.awt.Color(204, 204, 204));

        btnSearchProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnSearchProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchProduct.setText("Search");
        btnSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchProductActionPerformed(evt);
            }
        });

        TableParent.setBackground(new java.awt.Color(255, 255, 255));
        TableParent.setLayout(new java.awt.CardLayout());

        scrollpAllProducts.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollpAllProducts.setPreferredSize(new java.awt.Dimension(658, 298));

        tableAllProducts.setBackground(new java.awt.Color(255, 255, 255));
        tableAllProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Product Name", "Category", "Stock Level", "Reorder Level", "Price (Pesos)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableAllProducts.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tableAllProducts.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tableAllProducts.setPreferredSize(new java.awt.Dimension(658, 700));
        scrollpAllProducts.setViewportView(tableAllProducts);

        TableParent.add(scrollpAllProducts, "card2");

        scrollpProductExpiration.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollpProductExpiration.setPreferredSize(new java.awt.Dimension(658, 298));

        tableProductExpiration.setBackground(new java.awt.Color(255, 255, 255));
        tableProductExpiration.setForeground(new java.awt.Color(0, 0, 0));
        tableProductExpiration.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Product Name", "Category", "Expiration Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableProductExpiration.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tableProductExpiration.setPreferredSize(new java.awt.Dimension(658, 700));
        scrollpProductExpiration.setViewportView(tableProductExpiration);

        TableParent.add(scrollpProductExpiration, "card3");

        javax.swing.GroupLayout ViewInventoryPageLayout = new javax.swing.GroupLayout(ViewInventoryPage);
        ViewInventoryPage.setLayout(ViewInventoryPageLayout);
        ViewInventoryPageLayout.setHorizontalGroup(
            ViewInventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(ViewInventoryPageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ViewInventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ViewInventoryPageLayout.createSequentialGroup()
                        .addComponent(TableParent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(ViewInventoryPageLayout.createSequentialGroup()
                        .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnProductExpiration)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchProduct)
                        .addGap(14, 14, 14))))
        );
        ViewInventoryPageLayout.setVerticalGroup(
            ViewInventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ViewInventoryPageLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(TopPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ViewInventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSearchProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtSearchProduct)
                    .addComponent(btnProductExpiration, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbCategory))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TableParent, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
                .addContainerGap())
        );

        UserParent.add(ViewInventoryPage, "card3");

        RecordSalesPage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 51));
        jLabel11.setText("Sales");

        javax.swing.GroupLayout TopPanel2Layout = new javax.swing.GroupLayout(TopPanel2);
        TopPanel2.setLayout(TopPanel2Layout);
        TopPanel2Layout.setHorizontalGroup(
            TopPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TopPanel2Layout.setVerticalGroup(
            TopPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Select Product:");

        cmbSelectProduct.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbSelectProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbSelectProductActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Quantity:");

        txtQuantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQuantityActionPerformed(evt);
            }
        });

        btnAdd.setBackground(new java.awt.Color(0, 51, 102));
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        tableRecordSales.setBackground(new java.awt.Color(255, 255, 255));
        tableRecordSales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product Name", "Quantity", "Unit Price", "Sub Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableRecordSales);

        btnRemove.setBackground(new java.awt.Color(0, 51, 102));
        btnRemove.setForeground(new java.awt.Color(255, 255, 255));
        btnRemove.setText("Remove");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Total:");

        labelTotalPrice.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        labelTotalPrice.setForeground(new java.awt.Color(0, 0, 0));
        labelTotalPrice.setText("₱0.00");

        btnClear.setBackground(new java.awt.Color(0, 51, 102));
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnRecord.setBackground(new java.awt.Color(0, 51, 102));
        btnRecord.setForeground(new java.awt.Color(255, 255, 255));
        btnRecord.setText("Record");
        btnRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(119, 119, 119)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(33, 33, 33)))
                        .addGap(93, 93, 93)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbSelectProduct, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtQuantity, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(162, 162, 162)
                                .addComponent(btnAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btnRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(202, 202, 202)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(12, 12, 12)
                        .addComponent(labelTotalPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(261, 261, 261)
                        .addComponent(btnClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(122, 122, 122))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(cmbSelectProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnRemove, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(9, 9, 9))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labelTotalPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnRecord, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(btnClear, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout RecordSalesPageLayout = new javax.swing.GroupLayout(RecordSalesPage);
        RecordSalesPage.setLayout(RecordSalesPageLayout);
        RecordSalesPageLayout.setHorizontalGroup(
            RecordSalesPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RecordSalesPageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        RecordSalesPageLayout.setVerticalGroup(
            RecordSalesPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RecordSalesPageLayout.createSequentialGroup()
                .addComponent(TopPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        UserParent.add(RecordSalesPage, "card5");

        AlertsPage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 51));
        jLabel12.setText("Alerts");

        javax.swing.GroupLayout TopPanel3Layout = new javax.swing.GroupLayout(TopPanel3);
        TopPanel3.setLayout(TopPanel3Layout);
        TopPanel3Layout.setHorizontalGroup(
            TopPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(604, Short.MAX_VALUE))
        );
        TopPanel3Layout.setVerticalGroup(
            TopPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout AlertsPageLayout = new javax.swing.GroupLayout(AlertsPage);
        AlertsPage.setLayout(AlertsPageLayout);
        AlertsPageLayout.setHorizontalGroup(
            AlertsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        AlertsPageLayout.setVerticalGroup(
            AlertsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AlertsPageLayout.createSequentialGroup()
                .addComponent(TopPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(398, Short.MAX_VALUE))
        );

        UserParent.add(AlertsPage, "card4");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(UserParent, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LeftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(UserParent, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
  
//SIDEBAR MENU
    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        initChart();
        
        UserParent.removeAll();
        UserParent.add(HomePage);
        UserParent.repaint();
        UserParent.revalidate();
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnInventoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventoryActionPerformed
        String[] columnNames = {"Product ID", "Product Name", "Category", "Stock Level", "Reorder Level", "Price"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        tableAllProducts.setModel(model);
        
        loadData();
        
        UserParent.removeAll();
        UserParent.add(ViewInventoryPage);
        UserParent.repaint();
        UserParent.revalidate();
    }//GEN-LAST:event_btnInventoryActionPerformed

    private void btnAlertsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlertsActionPerformed
        UserParent.removeAll();
        UserParent.add(AlertsPage);
        UserParent.repaint();
        UserParent.revalidate();
    }//GEN-LAST:event_btnAlertsActionPerformed

    private void btnRecordSalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordSalesActionPerformed
        String[] columnNames = {"Product Name", "Quantity", "Unit Price", "Sub Total"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        tableRecordSales.setModel(model);
        
        isLoadingProducts = false;
        
        UserParent.removeAll();
        UserParent.add(RecordSalesPage);
        UserParent.repaint();
        UserParent.revalidate();
    
    }//GEN-LAST:event_btnRecordSalesActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginPage().setVisible(true);
                
            } else {
                
            }
    }//GEN-LAST:event_btnLogoutActionPerformed
//END SIDEBAR MENU

//INVENTORY PAGE EVENTS    
    private void btnProductExpirationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductExpirationActionPerformed
        if (btnProductExpiration.isSelected()){
            TableParent.removeAll();
            TableParent.add(scrollpProductExpiration);
            TableParent.repaint();
            TableParent.revalidate();
        } else{
            TableParent.removeAll();
            TableParent.add(scrollpAllProducts);
            TableParent.repaint();
            TableParent.revalidate();
        }
    }//GEN-LAST:event_btnProductExpirationActionPerformed
  
    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
        String selectedCategory = (String) cmbCategory.getSelectedItem();
    
        String baseQuery = "SELECT * FROM inventory";
        if (!"All".equals(selectedCategory)) {
            baseQuery += " WHERE category = '" + selectedCategory + "'";
        }

        // Clear both tables first
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(baseQuery)) {

            while (rs.next()) {
                // For tableAllProducts (full details)
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱" + rs.getString("price")
                });

                // For tableProductExpiration (only selected columns)
                model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void btnSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchProductActionPerformed
        String keyword = txtSearchProduct.getText().trim(); // assuming you have a JTextField named txtSearchProduct

        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a product name or ID to search.", "Input Needed", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);

        String query = "SELECT * FROM inventory WHERE product_name LIKE ? OR product_id LIKE ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, "%" + keyword + "%"); // For LIKE search
            try {
                int id = Integer.parseInt(keyword);
                pstmt.setInt(2, id); // Search by ID
            } catch (NumberFormatException e) {
                pstmt.setInt(2, -1); // Force no match if not a number
            }

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱" + rs.getString("price")
                });
                 model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error searching product: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSearchProductActionPerformed
//END INVENTORY PAGE EVENTS

//RECORD SALES PAGE EVENTS
    private void cmbSelectProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSelectProductActionPerformed
        if (isLoadingProducts==true) {
           
        } 
        else{
            String selectedProduct = (String) cmbSelectProduct.getSelectedItem();

            if (selectedProduct != null) {
                double unitPrice = getProductPrice(selectedProduct);
                int stockAvailable = getAvailableStock(selectedProduct);

                if (unitPrice >= 0) {
                    JOptionPane.showMessageDialog(this, 
                        "Price: ₱" + String.format("%.2f", unitPrice) + "\nAvailable Stock: " + stockAvailable,
                        "Product Information", 
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, 
                        "Product details not found.", 
                        "Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }//GEN-LAST:event_cmbSelectProductActionPerformed

    private void txtQuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQuantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQuantityActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        String productName = (String) cmbSelectProduct.getSelectedItem();
        String quantityStr = txtQuantity.getText().trim();

        if (productName == null || quantityStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a product and enter quantity.");
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);

            if (quantity <= 0) {
                JOptionPane.showMessageDialog(this, "Quantity must be greater than 0.");
                return;
            }

            // Check stock_level first
            int availableStock = getAvailableStock(productName);

            if (quantity > availableStock) {
                JOptionPane.showMessageDialog(this, "Not enough stock. Available: " + availableStock);
                return;
            }

            double unitPrice = getProductPrice(productName);
            double subtotal = unitPrice * quantity;

            DefaultTableModel model = (DefaultTableModel) tableRecordSales.getModel();
            model.addRow(new Object[]{productName, quantity, unitPrice, subtotal});

            updateTotal();

            txtQuantity.setText(""); // clear after adding

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for quantity.");
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        int selectedRow = tableRecordSales.getSelectedRow();
        if (selectedRow != -1) {
            DefaultTableModel model = (DefaultTableModel) tableRecordSales.getModel();
            model.removeRow(selectedRow);
            updateTotal();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to remove.");
        }
    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to clear table data?", "Clear", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                DefaultTableModel model = (DefaultTableModel) tableRecordSales.getModel();
                model.setRowCount(0); // Clear table
                updateTotal();
                
            } else {
                
            }
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordActionPerformed
        if (tableRecordSales.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No sales to record.");
            return;
        }

        try {Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            conn.setAutoCommit(false); // Start transaction

            for (int i = 0; i < tableRecordSales.getRowCount(); i++) {
                String productName = tableRecordSales.getValueAt(i, 0).toString();
                int quantity = Integer.parseInt(tableRecordSales.getValueAt(i, 1).toString());

                // Update inventory stock_level
                String updateSql = "UPDATE inventory SET stock_level = stock_level - ? WHERE product_name = ?";
                PreparedStatement pst = conn.prepareStatement(updateSql);
                pst.setInt(1, quantity);
                pst.setString(2, productName);
                pst.executeUpdate();
                pst.close();
            }

            conn.commit(); // Commit transaction
            JOptionPane.showMessageDialog(this, "Sales recorded successfully!");

            // Clear the table
            DefaultTableModel model = (DefaultTableModel) tableRecordSales.getModel();
            model.setRowCount(0);
            updateTotal();

        } catch (SQLException e) {
            try {Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
                conn.rollback(); // Rollback if error
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error recording sales: " + e.getMessage());
        } finally {
            try {Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_btnRecordActionPerformed
//END RECORD SALES PAGE EVENTS
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AlertsPage;
    private javax.swing.JPanel GraphPanel;
    private javax.swing.JPanel HomePage;
    private javax.swing.JPanel LeftPanel;
    private javax.swing.JPanel RecordSalesPage;
    private javax.swing.JPanel TableParent;
    private javax.swing.JPanel TopPanel;
    private javax.swing.JPanel TopPanel1;
    private javax.swing.JPanel TopPanel2;
    private javax.swing.JPanel TopPanel3;
    private javax.swing.JPanel UserParent;
    private javax.swing.JPanel ViewInventoryPage;
    private javax.swing.JButton btnAdd;
    private javax.swing.JToggleButton btnAlerts;
    private javax.swing.JButton btnClear;
    private javax.swing.JToggleButton btnHome;
    private javax.swing.JToggleButton btnInventory;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JToggleButton btnProductExpiration;
    private javax.swing.JButton btnRecord;
    private javax.swing.JToggleButton btnRecordSales;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnSearchProduct;
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JComboBox<String> cmbSelectProduct;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelTotalPrice;
    private javax.swing.JScrollPane scrollpAllProducts;
    private javax.swing.JScrollPane scrollpProductExpiration;
    private javax.swing.JTable tableAllProducts;
    private javax.swing.JTable tableProductExpiration;
    private javax.swing.JTable tableRecordSales;
    private javax.swing.JTextField txtQuantity;
    private javax.swing.JTextField txtSearchProduct;
    // End of variables declaration//GEN-END:variables
    }