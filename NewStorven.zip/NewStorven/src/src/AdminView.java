
package src;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.security.Timestamp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.XChartPanel;
import org.knowm.xchart.style.Styler;



public final class AdminView extends javax.swing.JFrame {

    public AdminView() {
        initComponents();
        setLocationRelativeTo(null);
        
        loadData();
        
        // Style the sales period toggle buttons
        styleSalesToggleButton(btnYesterday);
        styleSalesToggleButton(btnToday);
        styleSalesToggleButton(btnThisWeek);
        styleSalesToggleButton(btnThisMonth);
        styleSalesToggleButton(btnThisYear);

        // Add action listeners to time period buttons
        btnYesterday.addActionListener(e -> updateSalesDisplay("Yesterday"));
        btnToday.addActionListener(e -> updateSalesDisplay("Today"));
        btnThisWeek.addActionListener(e -> updateSalesDisplay("This Week"));
        btnThisMonth.addActionListener(e -> updateSalesDisplay("This Month"));
        btnThisYear.addActionListener(e -> updateSalesDisplay("This Year"));

        // Set default to Today
        updateSalesDisplay("Today");
        
        styleToggleButton(btnHome);
        styleToggleButton(btnInventory);
        styleToggleButton(btnNotifications);
        styleToggleButton(btnPurchase);
        styleToggleButton(btnSettings);
        
        btnHome.setSelected(true);
        
        buttonGroup();
        
        // In your constructor, replace the notification setup with:
        JButton btnMarkAllRead = new JButton("✓ Mark All as Read");
        btnMarkAllRead.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnMarkAllRead.setBackground(Color.WHITE);
        btnMarkAllRead.setFocusable(false);

        btnMarkAllRead.addActionListener(e -> {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
                 Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("UPDATE notifications SET is_read = 1 WHERE is_read = 0");
                loadNotifications();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Error marking all as read: " + ex.getMessage(), 
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        MidPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 10));
        MidPanel.add(btnMarkAllRead);

        JScrollPane notificationScroll = new JScrollPane(jPanel1);
        notificationScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        notificationScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        notificationScroll.getVerticalScrollBar().setUnitIncrement(16);

        REDUNDANCY3.setLayout(new BorderLayout());
        REDUNDANCY3.add(notificationScroll, BorderLayout.CENTER);
        
        initPurchasePage();
    }

//LEFT PANEL COMPONENTS/METHODS
    private void styleToggleButton(JToggleButton button) {
        button.setOpaque(true);
        button.setContentAreaFilled(true);

        button.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                if (button.isSelected()) {
                    button.setBackground(new Color(0, 0, 51));         // Dark Blue (Selected)
                    button.setForeground(new Color(255, 255, 255));         
                } else {
                    button.setBackground(new Color(255, 255, 255));    // White (Unselected)
                    button.setForeground(new Color(0, 0, 0));
                }
            }
        });
    }
    
    private void buttonGroup() {
        ButtonGroup toggleGroup = new ButtonGroup();
    
        toggleGroup.add(btnHome);
        toggleGroup.add(btnInventory);
        toggleGroup.add(btnNotifications);
        toggleGroup.add(btnPurchase);
        toggleGroup.add(btnSettings);
        toggleGroup.add(btnLogout);
    }
//END LEFT PANEL COMPONENTS/METHODS    

//HOMEPAGE COMPONENTS/METHODS
    // Helper method to get sales summary data
    private Map<String, Double> getSalesSummary(String timePeriod) {
        Map<String, Double> summary = new HashMap<>();
        summary.put("totalSales", 0.0);
        summary.put("itemsSold", 0.0);

        String query = "SELECT SUM(quantity_sold) as items_sold, SUM(sale_amount) as total_sales " +
                       "FROM salerecords WHERE ";

        switch (timePeriod) {
            case "Yesterday":
                query += "DATE(sale_datetime) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
                break;
            case "Today":
                query += "DATE(sale_datetime) = CURDATE()";
                break;
            case "This Week":
                query += "YEARWEEK(sale_datetime, 1) = YEARWEEK(CURDATE(), 1)";
                break;
            case "This Month":
                query += "YEAR(sale_datetime) = YEAR(CURDATE()) AND MONTH(sale_datetime) = MONTH(CURDATE())";
                break;
            case "This Year":
                query += "YEAR(sale_datetime) = YEAR(CURDATE())";
                break;
            default:
                query += "1=1"; // All time if no period matches
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                summary.put("itemsSold", rs.getDouble("items_sold"));
                summary.put("totalSales", rs.getDouble("total_sales"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading sales data: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        return summary;
    }

    // Method to update both sales display and chart
    private void updateSalesDisplay(String period) {
        // Update sales summary
        Map<String, Double> salesData = getSalesSummary(period);

        // Update the labels
        labelTotalSold.setText(String.valueOf((int)Math.round(salesData.get("itemsSold"))));
        labelTotalAmount.setText("₱" + String.format("%.2f", salesData.get("totalSales")));

        // Highlight the selected button
        btnYesterday.setSelected("Yesterday".equals(period));
        btnToday.setSelected("Today".equals(period));
        btnThisWeek.setSelected("This Week".equals(period));
        btnThisMonth.setSelected("This Month".equals(period));
        btnThisYear.setSelected("This Year".equals(period));

        // Update the chart
        initChart(period);
    }

    // Style the time period toggle buttons
    private void styleSalesToggleButton(JToggleButton button) {
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setFocusPainted(false);

        button.addChangeListener(e -> {
            if (button.isSelected()) {
                button.setBackground(new Color(0, 51, 102)); // Dark blue when selected
                button.setForeground(Color.WHITE);
            } else {
                button.setBackground(new Color(220, 220, 220)); // Light gray when not selected
                button.setForeground(Color.BLACK);
            }
        });
    }
    
    private String shortenName(String name, int maxLength) {
        if (name == null) return "";
        if (name.length() <= maxLength) return name;
        return name.substring(0, maxLength - 3) + "...";
    }
    
    private void initChart(String timePeriod) {
        // Get sales data from database for the specified time period
        Map<String, Integer> productSales = getProductSales(timePeriod);

        // Check if we have data to display
        if (productSales.isEmpty()) {
            GraphPanel.removeAll();

            JLabel noDataLabel = new JLabel("No sales data available for " + timePeriod, SwingConstants.CENTER);
            noDataLabel.setFont(new Font("Arial", Font.BOLD, 16));
            noDataLabel.setForeground(Color.GRAY);
            noDataLabel.setHorizontalTextPosition(SwingConstants.CENTER);
            noDataLabel.setVerticalTextPosition(SwingConstants.BOTTOM);

            GraphPanel.setLayout(new BorderLayout());
            GraphPanel.add(noDataLabel, BorderLayout.CENTER);

            GraphPanel.revalidate();
            GraphPanel.repaint();
            return;
        }

        // Create Chart
        CategoryChart chart = new CategoryChartBuilder()
                .width(800)
                .height(400)
                .title("Sales Overview - " + timePeriod)
                .xAxisTitle("Product")
                .yAxisTitle("Quantity Sold")
                .build();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setLegendVisible(false);
        chart.getStyler().setAvailableSpaceFill(0.8);
        chart.getStyler().setXAxisLabelRotation(90);
        chart.getStyler().setAxisTickLabelsFont(new Font("Arial", Font.BOLD, 10));
        chart.getStyler().setPlotMargin(10);
        chart.getStyler().setPlotContentSize(0.98);

        // Sort products by sales quantity (descending)
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(productSales.entrySet());
        sortedEntries.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        // Extract sorted product names and quantities
        List<String> productNames = new ArrayList<>();
        List<Integer> quantities = new ArrayList<>();

        for (Map.Entry<String, Integer> entry : sortedEntries) {
            productNames.add(shortenName(entry.getKey(), 12));
            quantities.add(entry.getValue());
        }

        // Add Series
        chart.addSeries("Products Sold", productNames, quantities);

        // Convert to Swing component
        JPanel chartPanel = new XChartPanel<>(chart);
        GraphPanel.removeAll();
        GraphPanel.add(chartPanel, BorderLayout.CENTER);
        GraphPanel.revalidate();
    }

    private Map<String, Integer> getProductSales(String timePeriod) {
        Map<String, Integer> sales = new HashMap<>();

        String query = "SELECT product_name, SUM(quantity_sold) as total " +
                       "FROM salerecords WHERE ";

        switch (timePeriod) {
            case "Yesterday":
                query += "DATE(sale_datetime) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
                break;
            case "Today":
                query += "DATE(sale_datetime) = CURDATE()";
                break;
            case "This Week":
                query += "YEARWEEK(sale_datetime, 1) = YEARWEEK(CURDATE(), 1)";
                break;
            case "This Month":
                query += "YEAR(sale_datetime) = YEAR(CURDATE()) AND MONTH(sale_datetime) = MONTH(CURDATE())";
                break;
            case "This Year":
                query += "YEAR(sale_datetime) = YEAR(CURDATE())";
                break;
            default:
                query += "1=1"; // All time if no period matches
        }

        query += " GROUP BY product_name";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                sales.put(rs.getString("product_name"), rs.getInt("total"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading sales data: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        return sales.isEmpty() ? Collections.emptyMap() : sales;
    }
//END OF HOMEPAGE COMPONENTS
    
//INVENTORY PAGE COMPONENTS/METHODS  
    public void loadData() {
        // Load data into tableAllProducts
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM inventory")) {
            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱ " + rs.getString("price")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory for All Products: " + e.getMessage());
        }

        // Load data into tableProductExpiration
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM inventory")) {
            while (rs.next()) {
                model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date"),
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory for Product Expiration: " + e.getMessage());
        }
    }
        
    public void refreshProductTable() {
        DefaultTableModel model = (DefaultTableModel) tableAllProducts.getModel();
        model.setRowCount(0); // Clear existing data

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT product_id, product_name, category, stock_level, reorder_level, price FROM inventory")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱ " + rs.getString("price")
                    // Note: Not including expiration_date in the table display
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error refreshing product table: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String getExpirationDateFromDB(int productId) {
        String expirationDate = "";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT expiration_date FROM inventory WHERE product_id = ?")) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                expirationDate = rs.getString("expiration_date");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading expiration date: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        return expirationDate;
    }
    
    private String getPriceFromDB(int productId) {
        String expirationDate = "";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT price FROM inventory WHERE product_id = ?")) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                expirationDate = rs.getString("price");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading expiration date: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        return expirationDate;
    }
    
    private void searchInventoryProducts(String keyword){
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);
        
        String query = "SELECT * FROM inventory";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "")) {
            PreparedStatement pstmt;

            if (keyword.isEmpty()) {
                pstmt = conn.prepareStatement(query);
            } else {
                query += " WHERE product_name LIKE ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, "%" + keyword + "%");
            }

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱" + rs.getString("price")
                });
                 model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching products: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
//END OF INVENTORY PAGE COMPONENTS/METHODS
    
//NOTIICATION PAGE COMPONENTS/METHODS    
    private void saveNotificationToDB(String message, String type, String productName) {
        String checkQuery = "SELECT notification_id FROM notifications WHERE type = ? AND product_name = ?";
        String updateQuery = "UPDATE notifications SET message = ?, created_at = CURRENT_TIMESTAMP, is_read = 0 WHERE notification_id = ?";
        String insertQuery = "INSERT INTO notifications (message, type, product_name, is_read) VALUES (?, ?, ?, 0)";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "")) {
            // Check if notification already exists
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, type);
            checkStmt.setString(2, productName);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                // Update existing notification with current timestamp
                int notificationId = rs.getInt("notification_id");
                PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                updateStmt.setString(1, message);
                updateStmt.setInt(2, notificationId);
                updateStmt.executeUpdate();
            } else {
                // Create new notification with current timestamp
                PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                insertStmt.setString(1, message);
                insertStmt.setString(2, type);
                insertStmt.setString(3, productName);
                insertStmt.executeUpdate();
            }
        } catch (Exception e) {
            System.err.println("Error saving notification: " + e.getMessage());
        }
    }
    
    private void markNotificationAsRead(int notificationId) {
        String query = "UPDATE notifications SET is_read = 1 WHERE notification_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, notificationId);
            stmt.executeUpdate();

        } catch (Exception e) {
            System.err.println("Error marking notification as read: " + e.getMessage());
        }
    }
    
    private void deleteNotificationFromDB(int notificationId) {
        String query = "DELETE FROM notifications WHERE notification_id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, notificationId);
            stmt.executeUpdate();

        } catch (Exception e) {
            System.err.println("Error deleting notification: " + e.getMessage());
        }
    }
    
    private void checkForNewNotifications() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "")) {
            // First, clear resolved notifications (where the condition no longer exists)
            clearResolvedNotifications(conn);

            // Then check for new notifications
            checkExpiringProducts(conn);
            checkOutOfStockProducts(conn);
            checkLowStockProducts(conn);
            checkSlowMovingProducts(conn);
            checkBestSellingProduct(conn);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error checking for new notifications: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearResolvedNotifications(Connection conn) throws SQLException {
        // Expired products that are no longer expiring soon
        String expiringQuery = "DELETE n FROM notifications n " +
                             "LEFT JOIN inventory i ON n.product_name = i.product_name " +
                             "WHERE n.type = 'EXPIRING' AND " +
                             "(i.expiration_date IS NULL OR i.expiration_date > DATE_ADD(CURDATE(), INTERVAL 10 DAY))";

        // Out of stock products that now have stock
        String outOfStockQuery = "DELETE n FROM notifications n " +
                               "LEFT JOIN inventory i ON n.product_name = i.product_name " +
                               "WHERE n.type = 'OUT_OF_STOCK' AND " +
                               "i.stock_level > 0";

        // Low stock products that now have sufficient stock
        String lowStockQuery = "DELETE n FROM notifications n " +
                             "LEFT JOIN inventory i ON n.product_name = i.product_name " +
                             "WHERE n.type = 'LOW_STOCK' AND " +
                             "i.stock_level > i.reorder_level";

        // Slow moving products that have new sales
        String slowMovingQuery = "DELETE n FROM notifications n " +
                               "WHERE n.type = 'SLOW_MOVING' AND " +
                               "EXISTS (SELECT 1 FROM salerecords s " +
                               "WHERE s.product_name = n.product_name " +
                               "AND s.sale_datetime >= DATE_SUB(CURDATE(), INTERVAL 14 DAY))";

        try (Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(expiringQuery);
            stmt.executeUpdate(outOfStockQuery);
            stmt.executeUpdate(lowStockQuery);
            stmt.executeUpdate(slowMovingQuery);
        }
    }
    
    private void checkExpiringProducts(Connection conn) throws SQLException {
        String query = "SELECT i.product_name, i.expiration_date " +
                     "FROM inventory i " +
                     "WHERE i.expiration_date IS NOT NULL " +
                     "AND i.expiration_date <= DATE_ADD(CURDATE(), INTERVAL 10 DAY)";

        try (PreparedStatement stmt = conn.prepareStatement(query); 
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("product_name");
                String expDate = rs.getString("expiration_date");
                saveNotificationToDB(
                    name + " is about to expire on " + expDate,
                    "EXPIRING",
                    name
                );
            }
        }
    }

    private void checkOutOfStockProducts(Connection conn) throws SQLException {
        String query = """
            SELECT i.product_name 
            FROM inventory i
            WHERE i.stock_level <= 0
            """;

        try (PreparedStatement stmt = conn.prepareStatement(query); 
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("product_name");
                saveNotificationToDB(
                    name + " is out of stock!",
                    "OUT_OF_STOCK",
                    name
                );
            }
        }
    }

    private void checkLowStockProducts(Connection conn) throws SQLException {
        String query = """
            SELECT i.product_name, i.stock_level 
            FROM inventory i
            WHERE i.stock_level > 0 
            AND i.stock_level <= i.reorder_level
            """;

        try (PreparedStatement stmt = conn.prepareStatement(query); 
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("product_name");
                int stock = rs.getInt("stock_level");
                saveNotificationToDB(
                    name + " has only " + stock + " left in stock.",
                    "LOW_STOCK",
                    name
                );
            }
        }
    }

    private void checkSlowMovingProducts(Connection conn) throws SQLException {
        String query = """
            SELECT i.product_name 
            FROM inventory i
            LEFT JOIN (
                SELECT product_name FROM salerecords
                WHERE sale_datetime >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)
            ) recent_sales ON i.product_name = recent_sales.product_name
            WHERE recent_sales.product_name IS NULL
            """;

        try (PreparedStatement stmt = conn.prepareStatement(query); 
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("product_name");
                saveNotificationToDB(
                    name + " had no sales in the past 14 days.",
                    "SLOW_MOVING",
                    name
                );
            }
        }
    }

    private void checkBestSellingProduct(Connection conn) throws SQLException {
        // Always delete previous best seller before adding new one
        String deleteQuery = "DELETE FROM notifications WHERE type = 'BEST_SELLER'";
        try (PreparedStatement stmt = conn.prepareStatement(deleteQuery)) {
            stmt.executeUpdate();
        }

        String query = "SELECT product_name, SUM(quantity_sold) AS total " +
                     "FROM salerecords " +
                     "WHERE sale_datetime >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) " +
                     "GROUP BY product_name " +
                     "ORDER BY total DESC " +
                     "LIMIT 1";

        try (PreparedStatement stmt = conn.prepareStatement(query); 
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                String name = rs.getString("product_name");
                int total = rs.getInt("total");
                saveNotificationToDB(
                    name + " sold " + total + " units in the last 7 days.",
                    "BEST_SELLER",
                    name
                );
            }
        }
    }
    
    private void loadNotificationsFromDB() {
        jPanel1.removeAll();
        jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.Y_AXIS));

        String query = "SELECT * FROM notifications ORDER BY created_at ASC";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm a");

            while (rs.next()) {
                int notificationId = rs.getInt("notification_id");
                String message = rs.getString("message");
                boolean isRead = rs.getBoolean("is_read");

                // Format timestamp directly here
                java.sql.Timestamp timestamp = rs.getTimestamp("created_at");
                String createdAt = (timestamp != null) ? 
                    dateFormat.format(timestamp) : "N/A";

                Color bgColor = isRead ? new Color(220, 220, 220) : getColorForType(rs.getString("type"));

                JPanel card = createNotificationCard(notificationId, message, createdAt, bgColor, isRead);
                jPanel1.add(card);
                jPanel1.add(Box.createVerticalStrut(8));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading notifications: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        jPanel1.revalidate();
        jPanel1.repaint();
    }
    
    private Color getColorForType(String type) {
        switch (type) {
            case "EXPIRING":
                return new Color(255, 153, 153); // light red
            case "OUT_OF_STOCK":
                return new Color(255, 51, 51); // bright red
            case "LOW_STOCK":
                return new Color(144, 238, 144); // light green
            case "SLOW_MOVING":
                return new Color(255, 102, 102); // medium red
            case "BEST_SELLER":
                return new Color(221, 160, 221); // light purple
            default:
                return Color.WHITE;
        }
    }
    
    private void loadNotifications() {
        jPanel1.removeAll();
        jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.Y_AXIS));

        // First, check for new notifications and save them to DB
        checkForNewNotifications();

        // Then load notifications from DB
        loadNotificationsFromDB();

        jPanel1.revalidate();
        jPanel1.repaint();
    }
    
    private JPanel createNotificationCard(int notificationId, String message, String dateTime, Color bgColor, boolean isRead) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(bgColor);
        card.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10),
            javax.swing.BorderFactory.createLineBorder(Color.GRAY)));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Main message
        JLabel lblMessage = new JLabel(message);
        lblMessage.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblMessage.setForeground(Color.BLACK);

        // Bottom right: time
        JLabel lblTime = new JLabel(dateTime);
        lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblTime.setForeground(Color.DARK_GRAY);

        // Action buttons
        JButton btnMarkAsRead = new JButton("✓ Read");
        JButton btnDelete = new JButton("🗑 Delete");
        btnMarkAsRead.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnDelete.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnMarkAsRead.setFocusable(false);
        btnDelete.setFocusable(false);

        if (isRead) {
            btnMarkAsRead.setEnabled(false);
        }

        // Action listeners
        btnMarkAsRead.addActionListener(e -> {
            markNotificationAsRead(notificationId);
            card.setBackground(new Color(220, 220, 220));
            btnMarkAsRead.setEnabled(false);
        });

        btnDelete.addActionListener(e -> {
            deleteNotificationFromDB(notificationId);
            jPanel1.remove(card);
            jPanel1.revalidate();
            jPanel1.repaint();
        });

        // Button panel (left)
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        leftPanel.setOpaque(false);
        leftPanel.add(btnMarkAsRead);
        leftPanel.add(btnDelete);

        // Time label (right)
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(lblTime);

        // Wrap buttons and time in bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);
        bottomPanel.add(leftPanel, BorderLayout.WEST);
        bottomPanel.add(rightPanel, BorderLayout.EAST);

        // Final layout
        card.add(lblMessage, BorderLayout.CENTER);
        card.add(bottomPanel, BorderLayout.SOUTH);

        return card;
    }
//END NOTIICATION PAGE COMPONENTS/METHODS    

//PURCHASE PAGE COMPONENTS/METHODS  
    // Add this method to your AdminView class
    private void initPurchasePage() {
        PurchaseContentPanel.setLayout(new BorderLayout());

        // Create top panel for purchase form
        JPanel purchaseFormPanel = new JPanel(new GridBagLayout());
        purchaseFormPanel.setBackground(Color.WHITE);
        purchaseFormPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Product Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        purchaseFormPanel.add(new JLabel("Product Name:"), gbc);

        gbc.gridx = 1;
        txtPurchaseProductName = new JTextField(20);
        purchaseFormPanel.add(txtPurchaseProductName, gbc);

        // Category
        gbc.gridx = 0;
        gbc.gridy = 1;
        purchaseFormPanel.add(new JLabel("Category:"), gbc);

        gbc.gridx = 1;
        cmbPurchaseCategory = new JComboBox<>(new String[] {
            "Snacks", "Canned & Instant Foods", "Beverages", 
            "Powdered Drinks", "Cooking Essentials", "Personal Care", 
            "Laundry & Cleaning Supplies", "School & Office Supplies"
        });
        cmbPurchaseCategory.setPreferredSize(new Dimension(231,30));
        purchaseFormPanel.add(cmbPurchaseCategory, gbc);

        // Quantity
        gbc.gridx = 0;
        gbc.gridy = 2;
        purchaseFormPanel.add(new JLabel("Quantity:"), gbc);

        gbc.gridx = 1;
        txtPurchaseQuantity = new JTextField(20);
        purchaseFormPanel.add(txtPurchaseQuantity, gbc);

        // Price
        gbc.gridx = 0;
        gbc.gridy = 3;
        purchaseFormPanel.add(new JLabel("Price per Unit:"), gbc);

        gbc.gridx = 1;
        txtPurchasePrice = new JTextField(20);
        purchaseFormPanel.add(txtPurchasePrice, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        btnAddPurchase = new JButton("Add Purchase");
        btnAddPurchase.setBackground(new Color(0, 51, 102));
        btnAddPurchase.setForeground(Color.WHITE);
        btnAddPurchase.addActionListener(this::btnAddPurchaseActionPerformed);

        btnRefreshPurchases = new JButton("Refresh");
        btnRefreshPurchases.setBackground(new Color(0, 51, 102));
        btnRefreshPurchases.setForeground(Color.WHITE);
        btnRefreshPurchases.addActionListener(this::btnRefreshPurchaseHistoryActionPerformed); // Add this line

        buttonPanel.add(btnAddPurchase);
        buttonPanel.add(btnRefreshPurchases);
        purchaseFormPanel.add(buttonPanel, gbc);
            
        // Create table for purchase history
        tablePurchasePageHistory = new JTable();
        scrollpPurchaseHistory = new JScrollPane(tablePurchasePageHistory);
        scrollpPurchaseHistory.setPreferredSize(new Dimension(650, 250));

        // Add components to main panel
        PurchaseContentPanel.add(purchaseFormPanel, BorderLayout.NORTH);
        PurchaseContentPanel.add(scrollpPurchaseHistory, BorderLayout.CENTER);

        // Load initial data
        loadPurchaseHistory();
    }

    private void loadPurchaseHistory() {
        String[] columnNames = {"Purchase ID", "Product Name", "Category", "Quantity", "Unit Price", "Total", "Date"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM purchases ORDER BY purchase_date DESC")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("purchase_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("quantity"),
                    "₱" + String.format("%.2f", rs.getDouble("unit_price")),
                    "₱" + String.format("%.2f", rs.getDouble("quantity") * rs.getDouble("unit_price")),
                    rs.getTimestamp("purchase_date")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading purchase history: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        tablePurchasePageHistory.setModel(model);
    }

    private void btnAddPurchaseActionPerformed(java.awt.event.ActionEvent evt) {
        // Validate inputs
        String productName = txtPurchaseProductName.getText().trim();
        String category = (String) cmbPurchaseCategory.getSelectedItem();
        String quantityStr = txtPurchaseQuantity.getText().trim();
        String priceStr = txtPurchasePrice.getText().trim();

        if (productName.isEmpty() || quantityStr.isEmpty() || priceStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please fill in all fields", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            double price = Double.parseDouble(priceStr);

            if (quantity <= 0 || price <= 0) {
                throw new NumberFormatException();
            }

            // Insert into database
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
                 PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO purchases (product_name, category, quantity, unit_price) VALUES (?, ?, ?, ?)")) {

                stmt.setString(1, productName);
                stmt.setString(2, category);
                stmt.setInt(3, quantity);
                stmt.setDouble(4, price);

                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Purchase recorded successfully!");

                    // Update inventory
                    updateInventory(productName, quantity);

                    // Clear form
                    txtPurchaseProductName.setText("");
                    txtPurchaseQuantity.setText("");
                    txtPurchasePrice.setText("");

                    // Refresh table
                    loadPurchaseHistory();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, 
                    "Error saving purchase: " + e.getMessage(), 
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid positive numbers for quantity and price", 
                "Validation Error", 
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void updateInventory(String productName, int quantity) {
        
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             PreparedStatement stmt = conn.prepareStatement(
                 "UPDATE inventory SET stock_level = stock_level + ? WHERE product_name = ?")) {

            stmt.setInt(1, quantity);
            stmt.setString(2, productName);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error updating inventory: " + e.getMessage());
        }
    }   
    
    private void btnRefreshPurchaseHistoryActionPerformed(java.awt.event.ActionEvent evt) {
    loadPurchaseHistory();
    JOptionPane.showMessageDialog(this, 
        "Purchase history refreshed successfully!", 
        "Refresh", 
        JOptionPane.INFORMATION_MESSAGE);
}
    
//END PURCHASE PAGE COMPONENTS/METHODS    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LeftPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnHome = new javax.swing.JToggleButton();
        btnInventory = new javax.swing.JToggleButton();
        btnNotifications = new javax.swing.JToggleButton();
        btnPurchase = new javax.swing.JToggleButton();
        btnSettings = new javax.swing.JToggleButton();
        btnLogout = new javax.swing.JToggleButton();
        AdminParent = new javax.swing.JPanel();
        HomePage = new javax.swing.JPanel();
        TopPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        TotalSalesPanel = new javax.swing.JPanel();
        btnYesterday = new javax.swing.JToggleButton();
        btnToday = new javax.swing.JToggleButton();
        btnThisWeek = new javax.swing.JToggleButton();
        btnThisMonth = new javax.swing.JToggleButton();
        btnThisYear = new javax.swing.JToggleButton();
        labelSoldItems = new javax.swing.JLabel();
        labelTotalSold = new javax.swing.JLabel();
        labelTotalSales = new javax.swing.JLabel();
        labelTotalAmount = new javax.swing.JLabel();
        REDUNDANCY1 = new javax.swing.JPanel();
        GraphPanel = new javax.swing.JPanel();
        InventoryPage = new javax.swing.JPanel();
        TopPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        btnProductExpiration = new javax.swing.JToggleButton();
        cmbCategory = new javax.swing.JComboBox<>();
        txtSearchProduct = new javax.swing.JTextField();
        btnSearchProduct = new javax.swing.JButton();
        REDUNDANCY2 = new javax.swing.JPanel();
        TableParent = new javax.swing.JPanel();
        scrollpAllProducts = new javax.swing.JScrollPane();
        tableAllProducts = new javax.swing.JTable();
        scrollpProductExpiration = new javax.swing.JScrollPane();
        tableProductExpiration = new javax.swing.JTable();
        btnAddProduct = new javax.swing.JButton();
        btnUpdateProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();
        NotificationsPage = new javax.swing.JPanel();
        TopPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        MidPanel = new javax.swing.JPanel();
        REDUNDANCY3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        PurchasePage = new javax.swing.JPanel();
        TopPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        PurchaseContentPanel = new javax.swing.JPanel();
        SettingsPage = new javax.swing.JPanel();
        TopPanel5 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LeftPanel.setBackground(new java.awt.Color(255, 255, 255));
        LeftPanel.setPreferredSize(new java.awt.Dimension(0, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 120x120.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setPreferredSize(new java.awt.Dimension(0, 0));

        btnHome.setBackground(new java.awt.Color(255, 255, 255));
        btnHome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnHome.setForeground(new java.awt.Color(0, 0, 51));
        btnHome.setText("    Home");
        btnHome.setBorder(null);
        btnHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnHome.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        btnInventory.setBackground(new java.awt.Color(255, 255, 255));
        btnInventory.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnInventory.setForeground(new java.awt.Color(0, 0, 51));
        btnInventory.setText("    Inventory");
        btnInventory.setBorder(null);
        btnInventory.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnInventory.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnInventory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventoryActionPerformed(evt);
            }
        });

        btnNotifications.setBackground(new java.awt.Color(255, 255, 255));
        btnNotifications.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnNotifications.setForeground(new java.awt.Color(0, 0, 51));
        btnNotifications.setText("    Notifications");
        btnNotifications.setBorder(null);
        btnNotifications.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNotifications.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnNotifications.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotificationsActionPerformed(evt);
            }
        });

        btnPurchase.setBackground(new java.awt.Color(255, 255, 255));
        btnPurchase.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnPurchase.setForeground(new java.awt.Color(0, 0, 51));
        btnPurchase.setText("    Purchase");
        btnPurchase.setBorder(null);
        btnPurchase.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPurchase.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnPurchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPurchaseActionPerformed(evt);
            }
        });

        btnSettings.setBackground(new java.awt.Color(255, 255, 255));
        btnSettings.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnSettings.setForeground(new java.awt.Color(0, 0, 51));
        btnSettings.setText("    Settings");
        btnSettings.setBorder(null);
        btnSettings.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSettings.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnSettings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSettingsActionPerformed(evt);
            }
        });

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(0, 0, 51));
        btnLogout.setText("    Logout");
        btnLogout.setBorder(null);
        btnLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLogout.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout LeftPanelLayout = new javax.swing.GroupLayout(LeftPanel);
        LeftPanel.setLayout(LeftPanelLayout);
        LeftPanelLayout.setHorizontalGroup(
            LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftPanelLayout.createSequentialGroup()
                .addGroup(LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnPurchase, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNotifications, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnInventory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnHome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnSettings, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5))
        );
        LeftPanelLayout.setVerticalGroup(
            LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInventory, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNotifications, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPurchase, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSettings, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        AdminParent.setBackground(new java.awt.Color(255, 255, 255));
        AdminParent.setPreferredSize(new java.awt.Dimension(0, 0));
        AdminParent.setLayout(new java.awt.CardLayout());

        HomePage.setBackground(new java.awt.Color(0, 0, 51));
        HomePage.setPreferredSize(new java.awt.Dimension(670, 460));

        TopPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 51));
        jLabel10.setText("Admin Home Page");

        javax.swing.GroupLayout TopPanel1Layout = new javax.swing.GroupLayout(TopPanel1);
        TopPanel1.setLayout(TopPanel1Layout);
        TopPanel1Layout.setHorizontalGroup(
            TopPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(463, Short.MAX_VALUE))
        );
        TopPanel1Layout.setVerticalGroup(
            TopPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        TotalSalesPanel.setBackground(new java.awt.Color(255, 255, 255));

        btnYesterday.setText("Yesterday");

        btnToday.setText("Today");

        btnThisWeek.setText("This Week");

        btnThisMonth.setText("This Month");

        btnThisYear.setText("This Year");

        labelSoldItems.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        labelSoldItems.setForeground(new java.awt.Color(0, 0, 0));
        labelSoldItems.setText("Sold Items:");

        labelTotalSold.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        labelTotalSold.setForeground(new java.awt.Color(0, 0, 0));
        labelTotalSold.setText("0");

        labelTotalSales.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        labelTotalSales.setForeground(new java.awt.Color(0, 0, 0));
        labelTotalSales.setText("Total Sales:");

        labelTotalAmount.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        labelTotalAmount.setForeground(new java.awt.Color(0, 0, 0));
        labelTotalAmount.setText("₱0.00");

        javax.swing.GroupLayout TotalSalesPanelLayout = new javax.swing.GroupLayout(TotalSalesPanel);
        TotalSalesPanel.setLayout(TotalSalesPanelLayout);
        TotalSalesPanelLayout.setHorizontalGroup(
            TotalSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TotalSalesPanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(TotalSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TotalSalesPanelLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(labelSoldItems)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelTotalSold)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelTotalSales)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelTotalAmount)
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TotalSalesPanelLayout.createSequentialGroup()
                        .addComponent(btnYesterday, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(btnToday, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(btnThisWeek, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(btnThisMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(btnThisYear, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(36, 36, 36))
        );
        TotalSalesPanelLayout.setVerticalGroup(
            TotalSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TotalSalesPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TotalSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnYesterday, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnToday, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThisWeek, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThisMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThisYear, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(TotalSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelTotalSales, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelTotalAmount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(labelSoldItems, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelTotalSold, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        GraphPanel.setLayout(new java.awt.CardLayout());

        javax.swing.GroupLayout REDUNDANCY1Layout = new javax.swing.GroupLayout(REDUNDANCY1);
        REDUNDANCY1.setLayout(REDUNDANCY1Layout);
        REDUNDANCY1Layout.setHorizontalGroup(
            REDUNDANCY1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(REDUNDANCY1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(REDUNDANCY1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(GraphPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 646, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        REDUNDANCY1Layout.setVerticalGroup(
            REDUNDANCY1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 294, Short.MAX_VALUE)
            .addGroup(REDUNDANCY1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(REDUNDANCY1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(GraphPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout HomePageLayout = new javax.swing.GroupLayout(HomePage);
        HomePage.setLayout(HomePageLayout);
        HomePageLayout.setHorizontalGroup(
            HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePageLayout.createSequentialGroup()
                .addComponent(TopPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(HomePageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(REDUNDANCY1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(TotalSalesPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        HomePageLayout.setVerticalGroup(
            HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePageLayout.createSequentialGroup()
                .addComponent(TopPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TotalSalesPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(REDUNDANCY1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        AdminParent.add(HomePage, "card2");

        InventoryPage.setBackground(new java.awt.Color(0, 0, 51));
        InventoryPage.setPreferredSize(new java.awt.Dimension(670, 460));

        TopPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 51));
        jLabel8.setText("Inventory");

        javax.swing.GroupLayout TopPanel2Layout = new javax.swing.GroupLayout(TopPanel2);
        TopPanel2.setLayout(TopPanel2Layout);
        TopPanel2Layout.setHorizontalGroup(
            TopPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TopPanel2Layout.setVerticalGroup(
            TopPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnProductExpiration.setBackground(new java.awt.Color(0, 51, 102));
        btnProductExpiration.setForeground(new java.awt.Color(255, 255, 255));
        btnProductExpiration.setText("Product Expiration");
        btnProductExpiration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductExpirationActionPerformed(evt);
            }
        });

        cmbCategory.setBackground(new java.awt.Color(0, 51, 102));
        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Snacks", "Canned & Instant Foods", "Beverages", "Powdered Drinks", "Cooking Essentials", "Personal Care", "Laundry & Cleaning Supplies", "School & Office Supplies" }));
        cmbCategory.setToolTipText("Category");
        cmbCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategoryActionPerformed(evt);
            }
        });

        txtSearchProduct.setBackground(new java.awt.Color(204, 204, 204));
        txtSearchProduct.setForeground(new java.awt.Color(0, 0, 0));
        txtSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchProductActionPerformed(evt);
            }
        });

        btnSearchProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnSearchProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchProduct.setText("Search");
        btnSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchProductActionPerformed(evt);
            }
        });

        TableParent.setBackground(new java.awt.Color(255, 255, 255));
        TableParent.setLayout(new java.awt.CardLayout());

        scrollpAllProducts.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollpAllProducts.setPreferredSize(new java.awt.Dimension(658, 298));

        tableAllProducts.setBackground(new java.awt.Color(255, 255, 255));
        tableAllProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Product Name", "Category", "Stock Level", "Reorder Level", "Price (Pesos)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableAllProducts.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tableAllProducts.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tableAllProducts.setMaximumSize(new java.awt.Dimension(214, 140));
        scrollpAllProducts.setViewportView(tableAllProducts);

        TableParent.add(scrollpAllProducts, "card2");

        scrollpProductExpiration.setViewportBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        scrollpProductExpiration.setColumnHeaderView(null);
        scrollpProductExpiration.setPreferredSize(new java.awt.Dimension(658, 298));

        tableProductExpiration.setBackground(new java.awt.Color(255, 255, 255));
        tableProductExpiration.setForeground(new java.awt.Color(0, 0, 0));
        tableProductExpiration.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Product Name", "Category", "Expiration Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableProductExpiration.setShowHorizontalLines(true);
        scrollpProductExpiration.setViewportView(tableProductExpiration);

        TableParent.add(scrollpProductExpiration, "card3");

        javax.swing.GroupLayout REDUNDANCY2Layout = new javax.swing.GroupLayout(REDUNDANCY2);
        REDUNDANCY2.setLayout(REDUNDANCY2Layout);
        REDUNDANCY2Layout.setHorizontalGroup(
            REDUNDANCY2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(REDUNDANCY2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TableParent, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        REDUNDANCY2Layout.setVerticalGroup(
            REDUNDANCY2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(REDUNDANCY2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TableParent, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)
                .addContainerGap())
        );

        btnAddProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnAddProduct.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnAddProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnAddProduct.setText("Add Product");
        btnAddProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProductActionPerformed(evt);
            }
        });

        btnUpdateProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnUpdateProduct.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnUpdateProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateProduct.setText("Update Product");
        btnUpdateProduct.setPreferredSize(new java.awt.Dimension(107, 27));
        btnUpdateProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnDeleteProduct.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnDeleteProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteProduct.setText("Delete Product");
        btnDeleteProduct.setPreferredSize(new java.awt.Dimension(107, 27));
        btnDeleteProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteProductActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout InventoryPageLayout = new javax.swing.GroupLayout(InventoryPage);
        InventoryPage.setLayout(InventoryPageLayout);
        InventoryPageLayout.setHorizontalGroup(
            InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryPageLayout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(btnAddProduct, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                .addGap(62, 62, 62)
                .addComponent(btnUpdateProduct, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                .addGap(75, 75, 75)
                .addComponent(btnDeleteProduct, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                .addGap(63, 63, 63))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryPageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(InventoryPageLayout.createSequentialGroup()
                        .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnProductExpiration)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchProduct))
                    .addComponent(REDUNDANCY2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        InventoryPageLayout.setVerticalGroup(
            InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryPageLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(TopPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchProduct)
                    .addComponent(btnProductExpiration)
                    .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(REDUNDANCY2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdateProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDeleteProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        AdminParent.add(InventoryPage, "card3");

        NotificationsPage.setBackground(new java.awt.Color(0, 0, 51));
        NotificationsPage.setPreferredSize(new java.awt.Dimension(670, 460));

        TopPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 51));
        jLabel11.setText("Notifications");

        javax.swing.GroupLayout TopPanel3Layout = new javax.swing.GroupLayout(TopPanel3);
        TopPanel3.setLayout(TopPanel3Layout);
        TopPanel3Layout.setHorizontalGroup(
            TopPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel11)
                .addContainerGap(520, Short.MAX_VALUE))
        );
        TopPanel3Layout.setVerticalGroup(
            TopPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel11)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        MidPanel.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout MidPanelLayout = new javax.swing.GroupLayout(MidPanel);
        MidPanel.setLayout(MidPanelLayout);
        MidPanelLayout.setHorizontalGroup(
            MidPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        MidPanelLayout.setVerticalGroup(
            MidPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        REDUNDANCY3.setPreferredSize(new java.awt.Dimension(630, 348));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 318, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout REDUNDANCY3Layout = new javax.swing.GroupLayout(REDUNDANCY3);
        REDUNDANCY3.setLayout(REDUNDANCY3Layout);
        REDUNDANCY3Layout.setHorizontalGroup(
            REDUNDANCY3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(REDUNDANCY3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        REDUNDANCY3Layout.setVerticalGroup(
            REDUNDANCY3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, REDUNDANCY3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout NotificationsPageLayout = new javax.swing.GroupLayout(NotificationsPage);
        NotificationsPage.setLayout(NotificationsPageLayout);
        NotificationsPageLayout.setHorizontalGroup(
            NotificationsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(NotificationsPageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(NotificationsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(REDUNDANCY3, javax.swing.GroupLayout.DEFAULT_SIZE, 658, Short.MAX_VALUE)
                    .addComponent(MidPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        NotificationsPageLayout.setVerticalGroup(
            NotificationsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NotificationsPageLayout.createSequentialGroup()
                .addComponent(TopPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MidPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(REDUNDANCY3, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
                .addContainerGap())
        );

        AdminParent.add(NotificationsPage, "card4");

        PurchasePage.setBackground(new java.awt.Color(0, 0, 51));
        PurchasePage.setPreferredSize(new java.awt.Dimension(670, 460));

        TopPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 51));
        jLabel12.setText("Purchase");

        javax.swing.GroupLayout TopPanel4Layout = new javax.swing.GroupLayout(TopPanel4);
        TopPanel4.setLayout(TopPanel4Layout);
        TopPanel4Layout.setHorizontalGroup(
            TopPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(569, Short.MAX_VALUE))
        );
        TopPanel4Layout.setVerticalGroup(
            TopPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout PurchaseContentPanelLayout = new javax.swing.GroupLayout(PurchaseContentPanel);
        PurchaseContentPanel.setLayout(PurchaseContentPanelLayout);
        PurchaseContentPanelLayout.setHorizontalGroup(
            PurchaseContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        PurchaseContentPanelLayout.setVerticalGroup(
            PurchaseContentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 386, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout PurchasePageLayout = new javax.swing.GroupLayout(PurchasePage);
        PurchasePage.setLayout(PurchasePageLayout);
        PurchasePageLayout.setHorizontalGroup(
            PurchasePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PurchasePageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(PurchaseContentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        PurchasePageLayout.setVerticalGroup(
            PurchasePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PurchasePageLayout.createSequentialGroup()
                .addComponent(TopPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PurchaseContentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        AdminParent.add(PurchasePage, "card5");

        SettingsPage.setBackground(new java.awt.Color(0, 0, 51));
        SettingsPage.setPreferredSize(new java.awt.Dimension(670, 460));

        TopPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 51));
        jLabel13.setText("Settings");

        javax.swing.GroupLayout TopPanel5Layout = new javax.swing.GroupLayout(TopPanel5);
        TopPanel5.setLayout(TopPanel5Layout);
        TopPanel5Layout.setHorizontalGroup(
            TopPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(578, Short.MAX_VALUE))
        );
        TopPanel5Layout.setVerticalGroup(
            TopPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout SettingsPageLayout = new javax.swing.GroupLayout(SettingsPage);
        SettingsPage.setLayout(SettingsPageLayout);
        SettingsPageLayout.setHorizontalGroup(
            SettingsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        SettingsPageLayout.setVerticalGroup(
            SettingsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SettingsPageLayout.createSequentialGroup()
                .addComponent(TopPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        AdminParent.add(SettingsPage, "card6");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(AdminParent, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LeftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
            .addComponent(AdminParent, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    
    
    
//SIDEBAR MENU
    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        
        
        AdminParent.removeAll();
        AdminParent.add(HomePage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnInventoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventoryActionPerformed
        // Example table model setup
        String[] columnNames = {"Product ID", "Product Name", "Category", "Stock Level", "Reorder Level", "Price"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        tableAllProducts.setModel(model);
        
        loadData();
                
        AdminParent.removeAll();
        AdminParent.add(InventoryPage);
        AdminParent.repaint();
        AdminParent.revalidate();      
    }//GEN-LAST:event_btnInventoryActionPerformed

    private void btnNotificationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotificationsActionPerformed
        loadNotifications();
        
        AdminParent.removeAll();
        AdminParent.add(NotificationsPage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnNotificationsActionPerformed

    private void btnPurchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPurchaseActionPerformed
        AdminParent.removeAll();
        AdminParent.add(PurchasePage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnPurchaseActionPerformed

    private void btnSettingsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSettingsActionPerformed
        AdminParent.removeAll();
        AdminParent.add(SettingsPage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnSettingsActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginPage().setVisible(true);
                
            } else {
                
            }
    }//GEN-LAST:event_btnLogoutActionPerformed
//END SIDEBAR MENU

//INVENTORY PAGE EVENTS
    private void btnAddProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProductActionPerformed
        InventoryAddProduct inventory = new InventoryAddProduct(this);
        inventory.setVisible(true);
    }//GEN-LAST:event_btnAddProductActionPerformed

    private void btnProductExpirationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductExpirationActionPerformed
        
        if (btnProductExpiration.isSelected()){
            TableParent.removeAll();
            TableParent.add(scrollpProductExpiration);
            TableParent.repaint();
            TableParent.revalidate();
        } else{        
            TableParent.removeAll();
            TableParent.add(scrollpAllProducts);
            TableParent.repaint();
            TableParent.revalidate();
        }
    }//GEN-LAST:event_btnProductExpirationActionPerformed

    private void btnUpdateProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateProductActionPerformed
        int selectedRow = tableAllProducts.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a product to update", 
                "No Selection", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Get data from selected row
            int productId = (int) tableAllProducts.getValueAt(selectedRow, 0); // ID is first column
            String productName = (String) tableAllProducts.getValueAt(selectedRow, 1);
            String category = (String) tableAllProducts.getValueAt(selectedRow, 2);
            int quantity = (int) tableAllProducts.getValueAt(selectedRow, 3);
            int reorderLevel = (int) tableAllProducts.getValueAt(selectedRow, 4);
            String price = (String) getPriceFromDB(productId);
            String expirationDate = (String) getExpirationDateFromDB(productId);

            // Open update form (ID is passed but not displayed)
            InventoryUpdateProduct updateForm = new InventoryUpdateProduct(
                productId, productName, category, quantity, 
                reorderLevel, price, expirationDate, this
            );
            updateForm.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error preparing update: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnUpdateProductActionPerformed

    private void btnDeleteProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteProductActionPerformed
        // Get the selected row
        int selectedRow = tableAllProducts.getSelectedRow();

        // Check if a row is actually selected
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a product by clicking on a row first", 
                "No Selection", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Get the Product ID from the selected row (first column)
        int productIdToDelete = (int) tableAllProducts.getValueAt(selectedRow, 0);

        // Confirmation dialog
        String productName = (String) tableAllProducts.getValueAt(selectedRow, 1);
        int confirm = JOptionPane.showConfirmDialog(
            this, 
            """
            Are you sure you want to delete:
            ID: """ + productIdToDelete + "\n" +
            "Name: " + productName + "?", 
            "Confirm Deletion", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );


        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM inventory WHERE product_id = ?")) {

                stmt.setInt(1, productIdToDelete);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Product deleted successfully!");
                    refreshProductTable(); // Refresh the table view
                } else {
                    JOptionPane.showMessageDialog(this, "Product not found in database!");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                    "Error deleting product: " + e.getMessage(), 
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnDeleteProductActionPerformed

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
        String selectedCategory = (String) cmbCategory.getSelectedItem();
    
        String baseQuery = "SELECT * FROM inventory";
        if (!"All".equals(selectedCategory)) {
            baseQuery += " WHERE category = '" + selectedCategory + "'";
        }

        // Clear both tables first
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(baseQuery)) {

            while (rs.next()) {
                // For tableAllProducts (full details)
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱" + rs.getString("price")
                });

                // For tableProductExpiration (only selected columns)
                model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void btnSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchProductActionPerformed
        String keyword = txtSearchProduct.getText().trim();
        searchInventoryProducts(keyword);
    }//GEN-LAST:event_btnSearchProductActionPerformed

    private void txtSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchProductActionPerformed
        String keyword = txtSearchProduct.getText().trim();
        searchInventoryProducts(keyword);
    }//GEN-LAST:event_txtSearchProductActionPerformed
//END INVENTORY PAGE EVENTS
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminView().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AdminParent;
    private javax.swing.JPanel GraphPanel;
    private javax.swing.JPanel HomePage;
    private javax.swing.JPanel InventoryPage;
    private javax.swing.JPanel LeftPanel;
    private javax.swing.JPanel MidPanel;
    private javax.swing.JPanel NotificationsPage;
    private javax.swing.JPanel PurchaseContentPanel;
    private javax.swing.JPanel PurchasePage;
    private javax.swing.JPanel REDUNDANCY1;
    private javax.swing.JPanel REDUNDANCY2;
    private javax.swing.JPanel REDUNDANCY3;
    private javax.swing.JPanel SettingsPage;
    private javax.swing.JPanel TableParent;
    private javax.swing.JPanel TopPanel1;
    private javax.swing.JPanel TopPanel2;
    private javax.swing.JPanel TopPanel3;
    private javax.swing.JPanel TopPanel4;
    private javax.swing.JPanel TopPanel5;
    private javax.swing.JPanel TotalSalesPanel;
    private javax.swing.JButton btnAddProduct;
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JToggleButton btnHome;
    private javax.swing.JToggleButton btnInventory;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JToggleButton btnNotifications;
    private javax.swing.JToggleButton btnProductExpiration;
    private javax.swing.JToggleButton btnPurchase;
    private javax.swing.JButton btnSearchProduct;
    private javax.swing.JToggleButton btnSettings;
    private javax.swing.JToggleButton btnThisMonth;
    private javax.swing.JToggleButton btnThisWeek;
    private javax.swing.JToggleButton btnThisYear;
    private javax.swing.JToggleButton btnToday;
    private javax.swing.JButton btnUpdateProduct;
    private javax.swing.JToggleButton btnYesterday;
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelSoldItems;
    private javax.swing.JLabel labelTotalAmount;
    private javax.swing.JLabel labelTotalSales;
    private javax.swing.JLabel labelTotalSold;
    private javax.swing.JScrollPane scrollpAllProducts;
    private javax.swing.JScrollPane scrollpProductExpiration;
    private javax.swing.JTable tableAllProducts;
    private javax.swing.JTable tableProductExpiration;
    private javax.swing.JTextField txtSearchProduct;
    // End of variables declaration//GEN-END:variables
    private javax.swing.JTable tablePurchasePageHistory;
    private javax.swing.JScrollPane scrollpPurchaseHistory;
    private javax.swing.JTextField txtPurchaseProductName;
    private javax.swing.JTextField txtPurchaseQuantity;
    private javax.swing.JTextField txtPurchasePrice;
    private javax.swing.JButton btnAddPurchase;
    private javax.swing.JButton btnRefreshPurchases;
    private javax.swing.JComboBox<String> cmbPurchaseCategory;
}