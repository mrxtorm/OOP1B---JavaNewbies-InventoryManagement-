
package src;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.XChartPanel;
import org.knowm.xchart.style.Styler;
import java.sql.*;



public final class AdminView extends javax.swing.JFrame {

    public AdminView() {
        initComponents();
        
        setLocationRelativeTo(null);
        
        initChart();
        loadData();
    }


//HOMEPAGE COMPONENTS
    private void initChart() {
        // Get data from database
        Map<String, Integer> categoryCounts = getCategoryCounts();

        // Check if we have data to display
        if (categoryCounts.isEmpty()) {
            GraphPanel.removeAll();

            JLabel noDataLabel = new JLabel("No inventory data available to display chart", SwingConstants.CENTER);
            noDataLabel.setFont(new Font("Arial", Font.BOLD, 16));
            noDataLabel.setForeground(Color.GRAY);
            noDataLabel.setHorizontalTextPosition(SwingConstants.CENTER);
            noDataLabel.setVerticalTextPosition(SwingConstants.BOTTOM);

            GraphPanel.setLayout(new BorderLayout()); // ensure it fills the panel
            GraphPanel.add(noDataLabel, BorderLayout.CENTER);

            GraphPanel.revalidate();
            GraphPanel.repaint();
            return;
        }


        // Create Chart
        CategoryChart chart = new CategoryChartBuilder()
                .width(800)
                .height(400)
                .title("Inventory Overview")
                .xAxisTitle("Category")
                .yAxisTitle("Quantity")
                .build();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setLegendVisible(false);
        chart.getStyler().setAvailableSpaceFill(0.9);

        // Add Series
        chart.addSeries("Products in Stock", 
                new ArrayList<>(categoryCounts.keySet()), 
                new ArrayList<>(categoryCounts.values()));

        // Convert to Swing component
        JPanel chartPanel = new XChartPanel<>(chart);
        GraphPanel.removeAll();
        GraphPanel.add(chartPanel, BorderLayout.CENTER);
        GraphPanel.revalidate();
    }
       
    private Map<String, Integer> getCategoryCounts() {
        Map<String, Integer> counts = new HashMap<>();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT category, SUM(stock_level) as total FROM inventory GROUP BY category")) {

            while (rs.next()) {
                counts.put(rs.getString("category"), rs.getInt("total"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading category data: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }

        // Return empty map instead of null if no data
        return counts.isEmpty() ? Collections.emptyMap() : counts;
    }
//END OF HOMEPAGE COMPONENTS
    
//INVENTORY PAGE COMPONENTS  
    public void loadData() {
        // Load data into tableAllProducts
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM inventory")) {
            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱ " + rs.getString("price")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory for All Products: " + e.getMessage());
        }

        // Load data into tableProductExpiration
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM inventory")) {
            while (rs.next()) {
                model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date"),
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory for Product Expiration: " + e.getMessage());
        }
    }
        
    public void refreshProductTable() {
        DefaultTableModel model = (DefaultTableModel) tableAllProducts.getModel();
        model.setRowCount(0); // Clear existing data

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT product_id, product_name, category, stock_level, reorder_level, price FROM inventory")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱ " + rs.getString("price")
                    // Note: Not including expiration_date in the table display
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error refreshing product table: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String getExpirationDateFromDB(int productId) {
        String expirationDate = "";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT expiration_date FROM inventory WHERE product_id = ?")) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                expirationDate = rs.getString("expiration_date");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading expiration date: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        return expirationDate;
    }
    
    private String getPriceFromDB(int productId) {
        String expirationDate = "";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT price FROM inventory WHERE product_id = ?")) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                expirationDate = rs.getString("price");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading expiration date: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
        return expirationDate;
    }
//END OF INVENTORY PAGE COMPONENTS
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LeftPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnHome = new javax.swing.JToggleButton();
        btnInventory = new javax.swing.JToggleButton();
        btnNotifications = new javax.swing.JToggleButton();
        btnPurchase = new javax.swing.JToggleButton();
        btnSettings = new javax.swing.JToggleButton();
        btnLogout = new javax.swing.JToggleButton();
        AdminParent = new javax.swing.JPanel();
        HomePage = new javax.swing.JPanel();
        TopPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        GraphPanel = new javax.swing.JPanel();
        InventoryPage = new javax.swing.JPanel();
        TopPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        btnProductExpiration = new javax.swing.JToggleButton();
        cmbCategory = new javax.swing.JComboBox<>();
        txtSearchProduct = new javax.swing.JTextField();
        btnSearchProduct = new javax.swing.JButton();
        TableParent = new javax.swing.JPanel();
        scrollpProductExpiration = new javax.swing.JScrollPane();
        tableProductExpiration = new javax.swing.JTable();
        scrollpAllProducts = new javax.swing.JScrollPane();
        tableAllProducts = new javax.swing.JTable();
        btnAddProduct = new javax.swing.JButton();
        btnUpdateProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();
        NotificationsPage = new javax.swing.JPanel();
        TopPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        PurchasePage = new javax.swing.JPanel();
        TopPanel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        SettingsPage = new javax.swing.JPanel();
        TopPanel5 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LeftPanel.setBackground(new java.awt.Color(255, 255, 255));
        LeftPanel.setPreferredSize(new java.awt.Dimension(0, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 120x120.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setPreferredSize(new java.awt.Dimension(0, 0));

        btnHome.setBackground(new java.awt.Color(255, 255, 255));
        btnHome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnHome.setForeground(new java.awt.Color(0, 0, 51));
        btnHome.setText("    Home");
        btnHome.setBorder(null);
        btnHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnHome.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        btnInventory.setBackground(new java.awt.Color(255, 255, 255));
        btnInventory.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnInventory.setForeground(new java.awt.Color(0, 0, 51));
        btnInventory.setText("    Inventory");
        btnInventory.setBorder(null);
        btnInventory.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnInventory.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnInventory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventoryActionPerformed(evt);
            }
        });

        btnNotifications.setBackground(new java.awt.Color(255, 255, 255));
        btnNotifications.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnNotifications.setForeground(new java.awt.Color(0, 0, 51));
        btnNotifications.setText("    Notifications");
        btnNotifications.setBorder(null);
        btnNotifications.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnNotifications.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnNotifications.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotificationsActionPerformed(evt);
            }
        });

        btnPurchase.setBackground(new java.awt.Color(255, 255, 255));
        btnPurchase.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnPurchase.setForeground(new java.awt.Color(0, 0, 51));
        btnPurchase.setText("    Purchase");
        btnPurchase.setBorder(null);
        btnPurchase.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnPurchase.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnPurchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPurchaseActionPerformed(evt);
            }
        });

        btnSettings.setBackground(new java.awt.Color(255, 255, 255));
        btnSettings.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnSettings.setForeground(new java.awt.Color(0, 0, 51));
        btnSettings.setText("    Settings");
        btnSettings.setBorder(null);
        btnSettings.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSettings.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnSettings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSettingsActionPerformed(evt);
            }
        });

        btnLogout.setBackground(new java.awt.Color(255, 255, 255));
        btnLogout.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(0, 0, 51));
        btnLogout.setText("    Logout");
        btnLogout.setBorder(null);
        btnLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLogout.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout LeftPanelLayout = new javax.swing.GroupLayout(LeftPanel);
        LeftPanel.setLayout(LeftPanelLayout);
        LeftPanelLayout.setHorizontalGroup(
            LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftPanelLayout.createSequentialGroup()
                .addGroup(LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnPurchase, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNotifications, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnInventory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnHome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(LeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnSettings, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(5, 5, 5))
        );
        LeftPanelLayout.setVerticalGroup(
            LeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnInventory, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnNotifications, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPurchase, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSettings, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        AdminParent.setBackground(new java.awt.Color(255, 255, 255));
        AdminParent.setPreferredSize(new java.awt.Dimension(0, 0));
        AdminParent.setLayout(new java.awt.CardLayout());

        HomePage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 51));
        jLabel10.setText("Admin Home Page");

        javax.swing.GroupLayout TopPanel1Layout = new javax.swing.GroupLayout(TopPanel1);
        TopPanel1.setLayout(TopPanel1Layout);
        TopPanel1Layout.setHorizontalGroup(
            TopPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addContainerGap(463, Short.MAX_VALUE))
        );
        TopPanel1Layout.setVerticalGroup(
            TopPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        GraphPanel.setLayout(new java.awt.CardLayout());

        javax.swing.GroupLayout HomePageLayout = new javax.swing.GroupLayout(HomePage);
        HomePage.setLayout(HomePageLayout);
        HomePageLayout.setHorizontalGroup(
            HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(HomePageLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(GraphPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        HomePageLayout.setVerticalGroup(
            HomePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePageLayout.createSequentialGroup()
                .addComponent(TopPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(GraphPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 386, Short.MAX_VALUE)
                .addContainerGap())
        );

        AdminParent.add(HomePage, "card2");

        InventoryPage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 51));
        jLabel8.setText("Inventory");

        javax.swing.GroupLayout TopPanel2Layout = new javax.swing.GroupLayout(TopPanel2);
        TopPanel2.setLayout(TopPanel2Layout);
        TopPanel2Layout.setHorizontalGroup(
            TopPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TopPanel2Layout.setVerticalGroup(
            TopPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnProductExpiration.setBackground(new java.awt.Color(0, 51, 102));
        btnProductExpiration.setForeground(new java.awt.Color(255, 255, 255));
        btnProductExpiration.setText("Product Expiration");
        btnProductExpiration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductExpirationActionPerformed(evt);
            }
        });

        cmbCategory.setBackground(new java.awt.Color(0, 51, 102));
        cmbCategory.setForeground(new java.awt.Color(255, 255, 255));
        cmbCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Snacks", "Canned & Instant Foods", "Beverages", "Powdered Drinks", "Cooking Essentials", "Personal Care", "Laundry & Cleaning Supplies", "School & Office Supplies" }));
        cmbCategory.setToolTipText("Category");
        cmbCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCategoryActionPerformed(evt);
            }
        });

        txtSearchProduct.setBackground(new java.awt.Color(204, 204, 204));
        txtSearchProduct.setForeground(new java.awt.Color(0, 0, 0));

        btnSearchProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnSearchProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchProduct.setText("Search");
        btnSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchProductActionPerformed(evt);
            }
        });

        TableParent.setBackground(new java.awt.Color(255, 255, 255));
        TableParent.setLayout(new java.awt.CardLayout());

        scrollpProductExpiration.setViewportBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        scrollpProductExpiration.setPreferredSize(new java.awt.Dimension(658, 298));

        tableProductExpiration.setBackground(new java.awt.Color(255, 255, 255));
        tableProductExpiration.setForeground(new java.awt.Color(0, 0, 0));
        tableProductExpiration.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Product Name", "Category", "Expiration Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableProductExpiration.setPreferredSize(new java.awt.Dimension(658, 1000));
        tableProductExpiration.setShowHorizontalLines(true);
        scrollpProductExpiration.setViewportView(tableProductExpiration);

        TableParent.add(scrollpProductExpiration, "card3");

        scrollpAllProducts.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollpAllProducts.setPreferredSize(new java.awt.Dimension(658, 298));

        tableAllProducts.setBackground(new java.awt.Color(255, 255, 255));
        tableAllProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product ID", "Product Name", "Category", "Stock Level", "Reorder Level", "Price (Pesos)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableAllProducts.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tableAllProducts.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tableAllProducts.setMaximumSize(new java.awt.Dimension(214, 140));
        tableAllProducts.setPreferredSize(new java.awt.Dimension(658, 1000));
        scrollpAllProducts.setViewportView(tableAllProducts);

        TableParent.add(scrollpAllProducts, "card2");

        btnAddProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnAddProduct.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnAddProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnAddProduct.setText("Add Product");
        btnAddProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProductActionPerformed(evt);
            }
        });

        btnUpdateProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnUpdateProduct.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnUpdateProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateProduct.setText("Update Product");
        btnUpdateProduct.setPreferredSize(new java.awt.Dimension(107, 27));
        btnUpdateProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setBackground(new java.awt.Color(0, 51, 102));
        btnDeleteProduct.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnDeleteProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteProduct.setText("Delete Product");
        btnDeleteProduct.setPreferredSize(new java.awt.Dimension(107, 27));
        btnDeleteProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteProductActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout InventoryPageLayout = new javax.swing.GroupLayout(InventoryPage);
        InventoryPage.setLayout(InventoryPageLayout);
        InventoryPageLayout.setHorizontalGroup(
            InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(InventoryPageLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TableParent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(InventoryPageLayout.createSequentialGroup()
                        .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnProductExpiration)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchProduct)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryPageLayout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(btnAddProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(62, 62, 62)
                .addComponent(btnUpdateProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(75, 75, 75)
                .addComponent(btnDeleteProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(63, 63, 63))
        );
        InventoryPageLayout.setVerticalGroup(
            InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InventoryPageLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(TopPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchProduct)
                    .addComponent(btnProductExpiration)
                    .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(TableParent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(InventoryPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdateProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDeleteProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        AdminParent.add(InventoryPage, "card3");

        NotificationsPage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 51));
        jLabel11.setText("Notifications");

        javax.swing.GroupLayout TopPanel3Layout = new javax.swing.GroupLayout(TopPanel3);
        TopPanel3.setLayout(TopPanel3Layout);
        TopPanel3Layout.setHorizontalGroup(
            TopPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addContainerGap(529, Short.MAX_VALUE))
        );
        TopPanel3Layout.setVerticalGroup(
            TopPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout NotificationsPageLayout = new javax.swing.GroupLayout(NotificationsPage);
        NotificationsPage.setLayout(NotificationsPageLayout);
        NotificationsPageLayout.setHorizontalGroup(
            NotificationsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        NotificationsPageLayout.setVerticalGroup(
            NotificationsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NotificationsPageLayout.createSequentialGroup()
                .addComponent(TopPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        AdminParent.add(NotificationsPage, "card4");

        PurchasePage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 51));
        jLabel12.setText("Purchase");

        javax.swing.GroupLayout TopPanel4Layout = new javax.swing.GroupLayout(TopPanel4);
        TopPanel4.setLayout(TopPanel4Layout);
        TopPanel4Layout.setHorizontalGroup(
            TopPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addContainerGap(569, Short.MAX_VALUE))
        );
        TopPanel4Layout.setVerticalGroup(
            TopPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout PurchasePageLayout = new javax.swing.GroupLayout(PurchasePage);
        PurchasePage.setLayout(PurchasePageLayout);
        PurchasePageLayout.setHorizontalGroup(
            PurchasePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PurchasePageLayout.setVerticalGroup(
            PurchasePageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PurchasePageLayout.createSequentialGroup()
                .addComponent(TopPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        AdminParent.add(PurchasePage, "card5");

        SettingsPage.setBackground(new java.awt.Color(0, 0, 51));

        TopPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 51));
        jLabel13.setText("Settings");

        javax.swing.GroupLayout TopPanel5Layout = new javax.swing.GroupLayout(TopPanel5);
        TopPanel5.setLayout(TopPanel5Layout);
        TopPanel5Layout.setHorizontalGroup(
            TopPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(578, Short.MAX_VALUE))
        );
        TopPanel5Layout.setVerticalGroup(
            TopPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout SettingsPageLayout = new javax.swing.GroupLayout(SettingsPage);
        SettingsPage.setLayout(SettingsPageLayout);
        SettingsPageLayout.setHorizontalGroup(
            SettingsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TopPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        SettingsPageLayout.setVerticalGroup(
            SettingsPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SettingsPageLayout.createSequentialGroup()
                .addComponent(TopPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        AdminParent.add(SettingsPage, "card6");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 670, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 460, Short.MAX_VALUE)
        );

        AdminParent.add(jPanel1, "card7");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 670, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 460, Short.MAX_VALUE)
        );

        AdminParent.add(jPanel2, "card8");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(LeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(AdminParent, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LeftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
            .addComponent(AdminParent, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    
    
    
//SIDEBAR MENU
    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
        initChart();
        
        AdminParent.removeAll();
        AdminParent.add(HomePage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnHomeActionPerformed

    private void btnInventoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventoryActionPerformed
        // Example table model setup
        String[] columnNames = {"Product ID", "Product Name", "Category", "Stock Level", "Reorder Level", "Price"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        tableAllProducts.setModel(model);
        
        loadData();
        
        AdminParent.removeAll();
        AdminParent.add(InventoryPage);
        AdminParent.repaint();
        AdminParent.revalidate();      
    }//GEN-LAST:event_btnInventoryActionPerformed

    private void btnNotificationsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotificationsActionPerformed
        AdminParent.removeAll();
        AdminParent.add(NotificationsPage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnNotificationsActionPerformed

    private void btnPurchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPurchaseActionPerformed
        AdminParent.removeAll();
        AdminParent.add(PurchasePage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnPurchaseActionPerformed

    private void btnSettingsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSettingsActionPerformed
        AdminParent.removeAll();
        AdminParent.add(SettingsPage);
        AdminParent.repaint();
        AdminParent.revalidate();
    }//GEN-LAST:event_btnSettingsActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginPage().setVisible(true);
                
            } else {
                
            }
    }//GEN-LAST:event_btnLogoutActionPerformed
//END SIDEBAR MENU

//INVENTORY PAGE EVENTS
    private void btnAddProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddProductActionPerformed
        InventoryAddProduct inventory = new InventoryAddProduct(this);
        inventory.setVisible(true);
    }//GEN-LAST:event_btnAddProductActionPerformed

    private void btnProductExpirationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductExpirationActionPerformed
        
        if (btnProductExpiration.isSelected()){
            TableParent.removeAll();
            TableParent.add(scrollpProductExpiration);
            TableParent.repaint();
            TableParent.revalidate();
        } else{        
            TableParent.removeAll();
            TableParent.add(scrollpAllProducts);
            TableParent.repaint();
            TableParent.revalidate();
        }
    }//GEN-LAST:event_btnProductExpirationActionPerformed

    private void btnUpdateProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateProductActionPerformed
        int selectedRow = tableAllProducts.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a product to update", 
                "No Selection", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // Get data from selected row
            int productId = (int) tableAllProducts.getValueAt(selectedRow, 0); // ID is first column
            String productName = (String) tableAllProducts.getValueAt(selectedRow, 1);
            String category = (String) tableAllProducts.getValueAt(selectedRow, 2);
            int quantity = (int) tableAllProducts.getValueAt(selectedRow, 3);
            int reorderLevel = (int) tableAllProducts.getValueAt(selectedRow, 4);
            String price = (String) getPriceFromDB(productId);
            String expirationDate = (String) getExpirationDateFromDB(productId);

            // Open update form (ID is passed but not displayed)
            InventoryUpdateProduct updateForm = new InventoryUpdateProduct(
                productId, productName, category, quantity, 
                reorderLevel, price, expirationDate, this
            );
            updateForm.setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Error preparing update: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnUpdateProductActionPerformed

    private void btnDeleteProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteProductActionPerformed
        // Get the selected row
        int selectedRow = tableAllProducts.getSelectedRow();

        // Check if a row is actually selected
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                "Please select a product by clicking on a row first", 
                "No Selection", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Get the Product ID from the selected row (first column)
        int productIdToDelete = (int) tableAllProducts.getValueAt(selectedRow, 0);

        // Confirmation dialog
        String productName = (String) tableAllProducts.getValueAt(selectedRow, 1);
        int confirm = JOptionPane.showConfirmDialog(
            this, 
            "Are you sure you want to delete:\n" +
            "ID: " + productIdToDelete + "\n" +
            "Name: " + productName + "?", 
            "Confirm Deletion", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );


        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM inventory WHERE product_id = ?")) {

                stmt.setInt(1, productIdToDelete);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Product deleted successfully!");
                    refreshProductTable(); // Refresh the table view
                } else {
                    JOptionPane.showMessageDialog(this, "Product not found in database!");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                    "Error deleting product: " + e.getMessage(), 
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btnDeleteProductActionPerformed

    private void cmbCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoryActionPerformed
        String selectedCategory = (String) cmbCategory.getSelectedItem();
    
        String baseQuery = "SELECT * FROM inventory";
        if (!"All".equals(selectedCategory)) {
            baseQuery += " WHERE category = '" + selectedCategory + "'";
        }

        // Clear both tables first
        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(baseQuery)) {

            while (rs.next()) {
                // For tableAllProducts (full details)
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱" + rs.getString("price")
                });

                // For tableProductExpiration (only selected columns)
                model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading inventory: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cmbCategoryActionPerformed

    private void btnSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchProductActionPerformed
        String keyword = txtSearchProduct.getText().trim(); // assuming you have a JTextField named txtSearchProduct
        
        
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a product name or ID to search.", "Input Needed", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel model1 = (DefaultTableModel) tableAllProducts.getModel();
        model1.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tableProductExpiration.getModel();
        model2.setRowCount(0);

        String query = "SELECT * FROM inventory WHERE product_name LIKE ? OR product_id LIKE ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/storvendb", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, "%" + keyword + "%"); // For LIKE search
            try {
                int id = Integer.parseInt(keyword);
                pstmt.setInt(2, id); // Search by ID
            } catch (NumberFormatException e) {
                pstmt.setInt(2, -1); // Force no match if not a number
            }

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model1.addRow(new Object[]{
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getInt("stock_level"),
                    rs.getInt("reorder_level"),
                    "₱" + rs.getString("price")
                });
                 model2.addRow(new Object[]{
                    rs.getString("product_name"),
                    rs.getString("category"),
                    rs.getString("expiration_date")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error searching product: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSearchProductActionPerformed
//END INVENTORY PAGE EVENTS
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminView().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AdminParent;
    private javax.swing.JPanel GraphPanel;
    private javax.swing.JPanel HomePage;
    private javax.swing.JPanel InventoryPage;
    private javax.swing.JPanel LeftPanel;
    private javax.swing.JPanel NotificationsPage;
    private javax.swing.JPanel PurchasePage;
    private javax.swing.JPanel SettingsPage;
    private javax.swing.JPanel TableParent;
    private javax.swing.JPanel TopPanel1;
    private javax.swing.JPanel TopPanel2;
    private javax.swing.JPanel TopPanel3;
    private javax.swing.JPanel TopPanel4;
    private javax.swing.JPanel TopPanel5;
    private javax.swing.JButton btnAddProduct;
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JToggleButton btnHome;
    private javax.swing.JToggleButton btnInventory;
    private javax.swing.JToggleButton btnLogout;
    private javax.swing.JToggleButton btnNotifications;
    private javax.swing.JToggleButton btnProductExpiration;
    private javax.swing.JToggleButton btnPurchase;
    private javax.swing.JButton btnSearchProduct;
    private javax.swing.JToggleButton btnSettings;
    private javax.swing.JButton btnUpdateProduct;
    private javax.swing.JComboBox<String> cmbCategory;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane scrollpAllProducts;
    private javax.swing.JScrollPane scrollpProductExpiration;
    private javax.swing.JTable tableAllProducts;
    private javax.swing.JTable tableProductExpiration;
    private javax.swing.JTextField txtSearchProduct;
    // End of variables declaration//GEN-END:variables
}